# PeraDock R8 para Windows x64

Extraia o ZIP, encerre a versão anterior do PeraDock e abra **PeraDock.exe**.

- **Configurações → Geral → Verificar atualizações** consulta a última versão publicada em GitHub Releases. Se houver uma versão mais recente, o PeraDock oferece abrir a página de download.
- O launcher carrega a lista e os ícones dos apps em segundo plano. O cache é reaproveitado ao reabrir a pesquisa.
- Em **Configurações → Dock**, desative **Mostrar Dock 1 no lugar da barra do Windows** para voltar à barra original. A Dock 2 continua disponível.
- **Configurações → Dock → Mostrar contorno da Dock 1** controla a linha em torno da dock principal.
- Na **Dock 2**, clique com o botão direito em um app e escolha **Adicionar separador abaixo**. Use o mesmo menu para remover a linha. A Dock 2 preserva a escolha de posição, tamanho, cor, transparência, contorno e ocultação.
- Os botões semáforo das Configurações pertencem à janela do PeraDock. A troca dos botões do Explorador é separada.

Base do dock: ArcDockWin 0.3.0, revisão 5759d8ff3df35ecc144da58447d8ec89b41ae2c0. Licença MIT incluída. A pasta Codigo-fonte contém o projeto e o script Compilar-PeraDock.ps1.