# Código-fonte do PeraDock R8

Execute Compilar-PeraDock.ps1 no PowerShell com Rust e Cargo instalados. Consulte a licença MIT em LICENSE.