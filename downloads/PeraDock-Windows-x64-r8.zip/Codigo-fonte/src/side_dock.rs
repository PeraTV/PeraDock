use std::cell::RefCell;
use std::path::Path;

use tiny_skia::{Pixmap, Rect, Transform};
use windows::Win32::Foundation::{COLORREF, HWND, LPARAM, LRESULT, POINT, RECT, SIZE, WPARAM};
use windows::Win32::Graphics::Gdi::{AC_SRC_ALPHA, AC_SRC_OVER, BLENDFUNCTION, GetMonitorInfoW, HMONITOR, MONITOR_DEFAULTTONULL, MONITOR_DEFAULTTOPRIMARY, MONITORINFO, MonitorFromWindow, ValidateRect};
use windows::Win32::System::Com::{CLSCTX_INPROC_SERVER, CoCreateInstance, CoTaskMemFree};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::Dialogs::{CC_FULLOPEN, CC_RGBINIT, CHOOSECOLORW, ChooseColorW};
use windows::Win32::UI::Shell::{DragAcceptFiles, DragFinish, DragQueryFileW, HDROP, FOS_FILEMUSTEXIST, FOS_FORCEFILESYSTEM, FileOpenDialog, IFileOpenDialog, SIGDN_FILESYSPATH};
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::core::w;

use crate::{apps::{self, App}, config, glass::Glass, render::{self, Direction, Metrics, Theme}};
use crate::panel::Buffer;

const TIMER_HOVER: usize = 1;
const TIMER_REFRESH: usize = 2;
const TIMER_VISIBILITY: usize = 3;

#[derive(Default)]
struct State {
    window: HWND,
    monitor: HMONITOR,
    monitor_bounds: RECT,
    bounds: RECT,
    visible: bool,
    peek: bool,
    foreground: HWND,
    glass: HWND,
    glass_fx: Option<Glass>,
    glass_rect: Option<(i32, i32, i32, i32)>,
    entries: Vec<App>,
    separators: Vec<String>,
    first: usize,
    capacity: usize,
    tracking: bool,
    mouse: f32,
    hover: f32,
    scale: f32,
    width: i32,
    length: i32,
    raster: Option<(Pixmap, Buffer)>,
}

impl State {
    fn metrics(&self) -> Metrics { Metrics::side(self.scale, config::side_icon_size(), config::side_animate()) }

    fn visible_count(&self) -> usize { self.entries.len().min(self.capacity) }

    fn visible_separators(&self) -> Vec<usize> {
        self.entries.iter().skip(self.first).take(self.visible_count()).enumerate()
            .filter_map(|(index, app)| self.separators.contains(&app.source).then_some(index)).collect()
    }

    fn slots(&self, m: &Metrics, separators: &[usize]) -> Vec<render::Slot> {
        render::layout(self.visible_count() + 1, separators, self.length as f32, m, self.mouse, self.hover)
    }

    fn hit(&self, lp: LPARAM) -> Option<usize> {
        let y = ((lp.0 >> 16) as i16) as f32;
        let m = self.metrics();
        self.slots(&m, &self.visible_separators()).iter().position(|slot| y >= slot.x - m.gap / 2.0
            && y < slot.x + slot.size + m.gap / 2.0)
    }
}

thread_local! { static DOCK: RefCell<State> = RefCell::new(State::default()); }

fn path() -> std::path::PathBuf { apps::config_path().with_file_name("dock-lateral.txt") }

fn save(list: &[String]) -> std::io::Result<()> {
    let path = path();
    if let Some(parent) = path.parent() { std::fs::create_dir_all(parent)?; }
    std::fs::write(path, list.join("\n") + "\n")
}

fn read() -> Vec<String> {
    std::fs::read_to_string(path()).unwrap_or_default().lines().map(str::trim)
        .filter(|line| !line.is_empty() && Path::new(line).is_file()).map(str::to_owned).collect()
}

pub fn count() -> usize { read().len() }

fn separators_path() -> std::path::PathBuf { path().with_file_name("dock-lateral-separadores.txt") }

fn read_separators() -> Vec<String> {
    std::fs::read_to_string(separators_path()).unwrap_or_default().lines().map(str::to_owned).collect()
}

fn save_separators(separators: &[String]) -> std::io::Result<()> {
    std::fs::write(separators_path(), separators.join("\n"))
}

pub fn add(owner: HWND) {
    let selected = unsafe {
        (|| -> windows::core::Result<String> {
            let picker: IFileOpenDialog = CoCreateInstance(&FileOpenDialog, None, CLSCTX_INPROC_SERVER)?;
            picker.SetTitle(w!("Adicionar aplicativo ou atalho à Dock 2"))?;
            picker.SetOptions(picker.GetOptions()? | FOS_FORCEFILESYSTEM | FOS_FILEMUSTEXIST)?;
            picker.SetFileTypes(&[windows::Win32::UI::Shell::Common::COMDLG_FILTERSPEC {
                pszName: w!("Aplicativos e atalhos"),
                pszSpec: w!("*.exe;*.lnk;*.url"),
            }])?;
            picker.Show(Some(owner))?;
            let result = picker.GetResult()?.GetDisplayName(SIGDN_FILESYSPATH)?;
            let selected = result.to_string();
            CoTaskMemFree(Some(result.0.cast()));
            Ok(selected?)
        })()
    };
    if let Ok(selected) = selected { add_paths([selected]); }
}

fn add_paths(files: impl IntoIterator<Item = String>) {
    let mut entries = read();
    let initial = entries.len();
    for file in files {
        let path = Path::new(&file);
        let allowed = path.extension().and_then(|x| x.to_str())
            .is_some_and(|x| ["exe", "lnk", "url"].iter().any(|kind| x.eq_ignore_ascii_case(kind)));
        if allowed && !file.contains(['\n', '\r']) && path.is_file()
            && !entries.iter().any(|entry| entry.eq_ignore_ascii_case(&file))
        {
            entries.push(file);
        }
    }
    if initial != entries.len() && save(&entries).is_ok() { sync(); }
}

fn drop_files(drop: HDROP) {
    let mut files = Vec::new();
    unsafe {
        for i in 0..DragQueryFileW(drop, u32::MAX, None) {
            let length = DragQueryFileW(drop, i, None);
            if length == 0 { continue; }
            let mut path = vec![0; length as usize + 1];
            let copied = DragQueryFileW(drop, i, Some(&mut path));
            if copied > 0 { files.push(String::from_utf16_lossy(&path[..copied as usize])); }
        }
        DragFinish(drop);
    }
    add_paths(files);
}

pub fn sync() {
    if !config::side_enabled() {
        shutdown();
        return;
    }
    let mut monitor = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
    let display = unsafe { MonitorFromWindow(HWND::default(), MONITOR_DEFAULTTOPRIMARY) };
    let scale = unsafe {
        if !GetMonitorInfoW(display, &mut monitor).as_bool() { return; }
        crate::monitor_scale(display)
    };
    let area = monitor.rcWork;
    let m = Metrics::side(scale, config::side_icon_size(), config::side_animate());
    let width = m.window_height();
    let space = (area.bottom - area.top - 2 * m.margin.ceil() as i32).max(1);
    let extra = 4.0 * (m.max - m.base) + 2.0 * m.pad;
    let sources = read();
    let separators: Vec<_> = read_separators().into_iter().filter(|entry| sources.contains(entry)).collect();
    let required_length = |apps: usize| {
        (apps + 1) as f32 * (m.base + m.gap) - m.gap + extra + apps.min(separators.len()) as f32 * m.sep
    };
    let mut capacity = sources.len();
    while capacity > 1 && required_length(capacity) > space as f32 { capacity -= 1; }
    let length = required_length(capacity).ceil().min(space as f32) as i32;
    let current = DOCK.with(|state| state.borrow().window);
    if current.is_invalid() {
        let Some((window, glass, fx)) = create_windows(m.radius) else { return; };
        DOCK.with(|state| {
            let mut state = state.borrow_mut();
            state.window = window;
            state.glass = glass;
            state.glass_fx = fx;
        });
    }
    let x = if config::side_right() { area.right - width } else { area.left };
    let y = area.top + (area.bottom - area.top - length) / 2;
    let window = DOCK.with(|state| {
        let mut state = state.borrow_mut();
        if state.scale != scale || state.entries.iter().map(|app| &app.source).ne(sources.iter()) {
            state.entries = sources.into_iter().map(|source| App {
                key: apps::source_key(&source),
                icon: apps::load_icon(&source, (96.0 * scale).ceil() as i32),
                source,
                pinned: true,
                windows: Vec::new(),
            }).collect();
            apps::refresh_pinned(&mut state.entries);
        }
        if state.scale != scale {
            if let Some(fx) = &state.glass_fx { fx.set_radius(m.radius); }
        }
        if state.width != width || state.length != length {
            state.raster = Pixmap::new(width as u32, length as u32).zip(Buffer::new(width, length));
        }
        state.scale = scale;
        state.width = width;
        state.length = length;
        state.monitor = display;
        state.monitor_bounds = monitor.rcMonitor;
        state.bounds = RECT { left: x, right: x + width, top: y, bottom: y + length };
        state.capacity = capacity;
        state.separators = separators;
        state.first = state.first.min(state.entries.len().saturating_sub(capacity));
        state.glass_rect = None;
        state.window
    });
    unsafe {
        let _ = SetWindowPos(window, Some(HWND_TOPMOST), x, y, width, length, SWP_NOACTIVATE);
        if config::side_autohide() {
            SetTimer(Some(window), TIMER_VISIBILITY, 75, None);
        } else {
            let _ = KillTimer(Some(window), TIMER_VISIBILITY);
        }
    }
    refresh_visibility();
    refresh_appearance();
}

fn create_windows(radius: f32) -> Option<(HWND, HWND, Option<Glass>)> {
    unsafe {
        let instance = GetModuleHandleW(None).ok()?.into();
        let class = w!("PeraDockSide");
        RegisterClassW(&WNDCLASSW {
            lpfnWndProc: Some(window_proc), hInstance: instance, lpszClassName: class,
            hCursor: LoadCursorW(None, IDC_HAND).unwrap_or_default(), ..Default::default()
        });
        let ex = WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
        let glass = CreateWindowExW(ex | WS_EX_NOREDIRECTIONBITMAP | WS_EX_TRANSPARENT,
            w!("ArcDockWinGlass"), w!("PeraDock Glass"), WS_POPUP,
            0, 0, 1, 1, None, None, Some(instance), None).ok()?;
        let Ok(window) = CreateWindowExW(ex | WS_EX_LAYERED, class, w!("PeraDock Dock 2"),
            WS_POPUP, 0, 0, 1, 1, Some(glass), None, Some(instance), None) else {
                let _ = DestroyWindow(glass);
                return None;
            };
        DragAcceptFiles(window, true);
        SetTimer(Some(window), TIMER_REFRESH, 1000, None);
        Some((window, glass, Glass::new(glass, radius).ok()))
    }
}

pub fn refresh_appearance() {
    DOCK.with(|state| {
        let mut state = state.borrow_mut();
        if state.visible {
            draw(&mut state);
        }
    });
}

fn refresh_visibility() {
    let foreground = unsafe { GetForegroundWindow() };
    let mut cursor = POINT::default();
    let cursor = unsafe { GetCursorPos(&mut cursor) }.ok().map(|()| cursor);
    DOCK.with(|state| apply_visibility(&mut state.borrow_mut(), foreground, cursor));
}

fn apply_visibility(state: &mut State, foreground: HWND, cursor: Option<POINT>) {
    if state.window.is_invalid() { return; }
    if state.foreground != foreground {
        state.foreground = foreground;
        state.peek = false;
    }
    let hide_for_app = config::side_autohide() && other_app_on_monitor(foreground, state.monitor);
    if hide_for_app {
        let bounds = state.bounds;
        let screen = state.monitor_bounds;
        let right = config::side_right();
        let reveal_strip = if right { screen.right - 3..screen.right } else { screen.left..screen.left + 3 };
        let dock_x = if right { bounds.left..screen.right } else { screen.left..bounds.right };
        state.peek = cursor.is_some_and(|p| {
            (bounds.top..bounds.bottom).contains(&p.y)
                && (reveal_strip.contains(&p.x) || (state.peek && dock_x.contains(&p.x)))
        });
    } else {
        state.peek = false;
    }
    let visible = !hide_for_app || state.peek;
    if visible == state.visible { return; }
    state.visible = visible;
    state.glass_rect = None;
    unsafe {
        if visible {
            draw(state);
            let _ = ShowWindow(state.window, SW_SHOWNOACTIVATE);
        } else {
            state.hover = 0.0;
            state.tracking = false;
            let _ = KillTimer(Some(state.window), TIMER_HOVER);
            let _ = ShowWindow(state.window, SW_HIDE);
            let _ = ShowWindow(state.glass, SW_HIDE);
        }
    }
}

fn other_app_on_monitor(window: HWND, monitor: HMONITOR) -> bool {
    unsafe {
        if window.is_invalid() || window == GetShellWindow() || window == GetDesktopWindow()
            || !IsWindowVisible(window).as_bool() || IsIconic(window).as_bool()
            || MonitorFromWindow(window, MONITOR_DEFAULTTONULL) != monitor
        {
            return false;
        }
        let mut pid = 0;
        GetWindowThreadProcessId(window, Some(&mut pid));
        if pid == std::process::id() { return false; }
        let mut class = [0u16; 64];
        let size = GetClassNameW(window, &mut class).max(0) as usize;
        ![w!("Progman"), w!("WorkerW"), w!("Shell_TrayWnd"), w!("Shell_SecondaryTrayWnd")]
            .iter().any(|name| name.as_wide() == &class[..size])
    }
}

pub fn pick_color(owner: HWND) {
    let [r, g, b] = config::side_color().unwrap_or_else(|| {
        if crate::light_theme() { [250, 250, 252] } else { [40, 40, 44] }
    });
    let mut custom = [COLORREF(0x00FFFFFF); 16];
    let mut choice = CHOOSECOLORW {
        lStructSize: size_of::<CHOOSECOLORW>() as u32,
        hwndOwner: owner,
        rgbResult: COLORREF(u32::from(r) | u32::from(g) << 8 | u32::from(b) << 16),
        lpCustColors: custom.as_mut_ptr(),
        Flags: CC_RGBINIT | CC_FULLOPEN,
        ..Default::default()
    };
    if unsafe { ChooseColorW(&mut choice) }.as_bool() {
        let color = choice.rgbResult.0;
        config::set_side_color(Some([color as u8, (color >> 8) as u8, (color >> 16) as u8]));
        refresh_appearance();
    }
}

fn animate_tick() -> bool {
    DOCK.with(|state| {
        let mut state = state.borrow_mut();
        let target = if state.tracking && config::side_animate() { 1.0 } else { 0.0 };
        state.hover += (target - state.hover) * 0.25;
        if (target - state.hover).abs() < 0.015 {
            state.hover = target;
            false
        } else {
            true
        }
    })
}

pub fn shutdown() {
    let mut state = DOCK.with(|state| std::mem::take(&mut *state.borrow_mut()));
    state.glass_fx = None;
    if !state.window.is_invalid() {
        unsafe {
            let _ = DestroyWindow(state.window);
            let _ = DestroyWindow(state.glass);
        }
    }
}

fn draw(state: &mut State) {
    let m = state.metrics();
    let separators = state.visible_separators();
    let slots = state.slots(&m, &separators);
    let direction = if config::side_right() { Direction::Right } else { Direction::Left };
    let light = crate::light_theme();
    let percent = config::side_transparency();
    let color = config::side_color();
    let theme = Theme::new(light, crate::accent_color()).side(percent, color, config::side_border());
    let contrast = color.filter(|_| percent < 45.0)
        .map_or(light, |[r, g, b]| u32::from(r) * 299 + u32::from(g) * 587 + u32::from(b) * 114 >= 145_000);
    let mut origin = windows::Win32::Foundation::RECT::default();
    if unsafe { GetWindowRect(state.window, &mut origin) }.is_err() { return; }
    let glass_rect = render::box_rect(&slots, &m, state.width as f32)
        .map(|(l, t, r, b)| direction.rect(l, t, r, b, state.width))
        .map(|(l, t, r, b)| (origin.left + l, origin.top + t, r - l, b - t));
    if let Some(fx) = &state.glass_fx {
        fx.set_opacity(((100.0 - percent) / 88.0).min(1.0));
        if state.glass_rect != glass_rect && let Some((x, y, w, h)) = glass_rect {
            fx.resize(w as f32, h as f32);
            unsafe {
                let _ = SetWindowPos(state.glass, None, x, y, w, h,
                    SWP_NOACTIVATE | SWP_NOZORDER | SWP_SHOWWINDOW);
            }
        }
    }
    state.glass_rect = glass_rect;
    let add = App {
        source: String::new(), key: String::new(), pinned: true,
        icon: add_icon(contrast), windows: Vec::new(),
    };
    let items: Vec<&App> = state.entries.iter().skip(state.first).take(state.visible_count())
        .chain(std::iter::once(&add)).collect();
    let fg = unsafe { GetForegroundWindow() };
    let focus = items.iter().position(|app| app.windows.contains(&fg));
    let Some((image, buffer)) = &mut state.raster else { return; };
    render::draw_oriented(image, &slots, &separators, &items, &m, &theme, state.hover, focus,
        state.tracking, direction);
    let bytes = unsafe { std::slice::from_raw_parts_mut(buffer.bits, image.data().len()) };
    for (d, s) in bytes.chunks_exact_mut(4).zip(image.data().chunks_exact(4)) {
        d.copy_from_slice(&[s[2], s[1], s[0], s[3]]);
    }
    let size = SIZE { cx: buffer.w, cy: buffer.h };
    let blend = BLENDFUNCTION { BlendOp: AC_SRC_OVER as u8, BlendFlags: 0,
        SourceConstantAlpha: 255, AlphaFormat: AC_SRC_ALPHA as u8 };
    unsafe {
        let _ = UpdateLayeredWindow(state.window, None, None, Some(&size), Some(buffer.memdc),
            Some(&POINT::default()), COLORREF(0), Some(&blend), ULW_ALPHA);
    }
}

fn add_icon(light: bool) -> Option<Pixmap> {
    let mut icon = Pixmap::new(48, 48)?;
    let mut paint = tiny_skia::Paint::default();
    let value = if light { 38 } else { 241 };
    paint.set_color_rgba8(value, value, value, 240);
    for (x, y, width, height) in [(12.0, 22.5, 24.0, 3.0), (22.5, 12.0, 3.0, 24.0)] {
        icon.fill_rect(Rect::from_xywh(x, y, width, height)?, &paint, Transform::identity(), None);
    }
    Some(icon)
}

unsafe extern "system" fn window_proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    unsafe {
        match msg {
            WM_PAINT => { let _ = ValidateRect(Some(hwnd), None); }
            WM_DROPFILES => drop_files(HDROP(wp.0 as *mut std::ffi::c_void)),
            WM_TIMER if wp.0 == TIMER_HOVER => {
                if !animate_tick() { let _ = KillTimer(Some(hwnd), TIMER_HOVER); }
                refresh_appearance();
            }
            WM_TIMER if wp.0 == TIMER_VISIBILITY => refresh_visibility(),
            WM_TIMER if wp.0 == TIMER_REFRESH => {
                DOCK.with(|state| { apps::refresh_pinned(&mut state.borrow_mut().entries); });
                refresh_appearance();
            }
            WM_MOUSEACTIVATE => return LRESULT(MA_NOACTIVATE as isize),
            WM_ERASEBKGND => return LRESULT(1),
            WM_MOUSEMOVE | 0x02a3 => {
                let started = DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    let started = !state.tracking && msg == WM_MOUSEMOVE;
                    if started {
                        use windows::Win32::UI::Input::KeyboardAndMouse::*;
                        let mut event = TRACKMOUSEEVENT {
                            cbSize: size_of::<TRACKMOUSEEVENT>() as u32, dwFlags: TME_LEAVE,
                            hwndTrack: hwnd, dwHoverTime: 0,
                        };
                        let _ = TrackMouseEvent(&mut event);
                    }
                    state.tracking = msg == WM_MOUSEMOVE;
                    if state.tracking { state.mouse = ((lp.0 >> 16) as i16) as f32; }
                    started
                });
                if config::side_animate() {
                    if started || msg == 0x02a3 { SetTimer(Some(hwnd), TIMER_HOVER, 16, None); }
                    refresh_appearance();
                }
            }
            WM_MOUSEWHEEL => {
                DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    let steps = ((wp.0 >> 16) as i16 / 120).clamp(-6,6) as isize;
                    let last = state.entries.len().saturating_sub(state.capacity);
                    state.first = state.first.saturating_add_signed(-steps).min(last);
                });
                refresh_appearance();
            }
            WM_LBUTTONUP => {
                let (plus, target) = DOCK.with(|state| {
                    let state = state.borrow();
                    let Some(row) = state.hit(lp) else { return (false, None); };
                    let plus = row == state.visible_count();
                    (plus, state.entries.get(state.first + row).map(|app| (app.source.clone(), app.windows.clone())))
                });
                if plus { add(hwnd); } else if let Some((source, windows)) = target { apps::activate(&source, &windows); }
            }
            WM_RBUTTONUP => {
                let selected = DOCK.with(|state| {
                    let state = state.borrow();
                    let row = state.hit(lp)?;
                    if row >= state.visible_count() { return None; }
                    state.entries.get(state.first + row).map(|app| app.source.clone())
                });
                if let Some(selected) = selected && let Ok(menu) = CreatePopupMenu() {
                    let mut separators = read_separators();
                    let separator = separators.iter().position(|path| path == &selected);
                    let label = if separator.is_some() { w!("Remover separador abaixo") } else { w!("Adicionar separador abaixo") };
                    let _ = AppendMenuW(menu, MF_STRING, 2, label);
                    let _ = AppendMenuW(menu, MF_STRING, 1, w!("Remover da Dock 2"));
                    let mut point = windows::Win32::Foundation::POINT::default();
                    let _ = GetCursorPos(&mut point);
                    let _ = SetForegroundWindow(hwnd);
                    let chosen = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON, point.x, point.y, None, hwnd, None);
                    let _ = DestroyMenu(menu);
                    if chosen.0 == 1 {
                        let mut list = read();
                        list.retain(|path| path != &selected);
                        if save(&list).is_ok() {
                            separators.retain(|path| path != &selected);
                            let _ = save_separators(&separators);
                            sync();
                        }
                    } else if chosen.0 == 2 {
                        if let Some(position) = separator {
                            separators.remove(position);
                        } else {
                            separators.push(selected);
                        }
                        if save_separators(&separators).is_ok() { sync(); }
                    }
                }
            }
            WM_DISPLAYCHANGE | WM_DPICHANGED => { let _ = PostMessageW(Some(hwnd), WM_APP + 1, WPARAM(0), LPARAM(0)); }
            WM_CLOSE => {
                config::set_side_enabled(false);
                shutdown();
            }
            x if x == WM_APP + 1 => sync(),
            _ => return DefWindowProcW(hwnd,msg,wp,lp),
        }
        LRESULT(0)
    }
}
