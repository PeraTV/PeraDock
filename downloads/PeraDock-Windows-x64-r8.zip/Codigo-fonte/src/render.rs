//! Layout com zoom estilo macOS e desenho do dock.

use std::f32::consts::PI;

use tiny_skia::{
    Color, FillRule, FilterQuality, Paint, PathBuilder, Pixmap, PixmapPaint, Rect, Stroke,
    Transform,
};

use crate::apps::App;

pub struct Metrics {
    pub base: f32,   // tamanho normal do ícone
    pub max: f32,    // tamanho máximo com zoom
    pub gap: f32,    // espaço entre ícones
    pub sep: f32,    // espaço extra do separador (fixados | abertos)
    pub pad: f32,    // espaço interno do fundo
    pub margin: f32, // distância até a borda de baixo
    pub range: f32,  // raio de alcance do zoom
    pub radius: f32, // arredondamento do fundo
    pub dot: f32,    // raio do indicador de app aberto
}

impl Metrics {
    /// Tamanho dos ícones e ampliação vêm das Configurações (config.rs).
    pub fn new(scale: f32) -> Self {
        Self::scaled(scale, crate::config::icon_size(), crate::config::magnify())
    }

    pub fn side(scale: f32, size: f32, animate: bool) -> Self {
        Self::scaled(scale, size, animate)
    }

    fn scaled(scale: f32, size: f32, animate: bool) -> Self {
        let (base, gap) = (size * scale, 9.0 * scale);
        let zoom = if animate { crate::config::magnify_scale() } else { 1.0 };
        Self {
            base,
            max: base * zoom,
            gap,
            sep: 10.0 * scale, // espaçamento simétrico em torno do divisor
            pad: 8.0 * scale,
            margin: 6.0 * scale,
            range: 2.0 * (base + gap), // 2 slots de cada lado
            radius: 20.0 * scale,
            dot: 1.7 * scale,
        }
    }

    pub fn window_height(&self) -> i32 {
        (self.margin + self.base + 2.0 * self.pad + (self.max - self.base) + self.pad).ceil() as i32
    }
}

pub struct Theme {
    tint: [u8; 4],
    border: [u8; 4],
    dot: [u8; 4],
    divider: [u8; 4],
    /// Pontinhos do app em foco: cor de destaque do Windows.
    accent: [u8; 4],
}

impl Theme {
    pub fn new(light: bool, accent: Option<[u8; 4]>) -> Self {
        let (tint, border, dot, divider) = if light {
            ([250, 250, 252, 108], [255, 255, 255, 178], [0, 0, 0, 170], [0, 0, 0, 45])
        } else {
            ([40, 40, 44, 116], [255, 255, 255, 58], [255, 255, 255, 210], [255, 255, 255, 60])
        };
        Self { tint, border, dot, divider, accent: accent.unwrap_or(dot) }
    }

    pub fn with_border(mut self, visible: bool) -> Self {
        if !visible { self.border[3] = 0; }
        self
    }

    pub fn side(mut self, percent: f32, color: Option<[u8; 3]>, border: bool) -> Self {
        if let Some(color) = color {
            self.tint[..3].copy_from_slice(&color);
        }
        if !border {
            self.border[3] = 0;
        }
        let alpha = self.tint[3] as f32;
        self.tint[3] = if percent < 12.0 {
            (255.0 + (alpha - 255.0) * percent / 12.0).round() as u8
        } else {
            (alpha * (100.0 - percent) / 88.0).round() as u8
        };
        self
    }
}

pub struct Slot {
    pub x: f32,
    pub size: f32,
    /// Deslocamento só do desenho do ícone (arrastado), sem mexer no fundo nem no separador.
    pub dx: f32,
}

/// Posição e tamanho de cada ícone dado o mouse em `mx` e a intensidade do hover (0..1).
/// `seps`: índices dos itens com separador depois (último fixado; último app antes das pilhas).
pub fn layout(n: usize, seps: &[usize], width: f32, m: &Metrics, mx: f32, hover: f32) -> Vec<Slot> {
    if n == 0 {
        return Vec::new();
    }
    let extra = |i: usize| m.sep * seps.iter().filter(|&&s| i > s).count() as f32;
    let base_total = n as f32 * m.base + (n - 1) as f32 * m.gap + extra(n - 1);
    let base_left = (width - base_total) / 2.0;

    let sizes: Vec<f32> = (0..n)
        .map(|i| {
            let center = base_left + i as f32 * (m.base + m.gap) + extra(i) + m.base / 2.0;
            let d = (mx - center).abs();
            let f = if d < m.range { 0.5 * (1.0 + (PI * d / m.range).cos()) } else { 0.0 };
            m.base + (m.max - m.base) * f * hover
        })
        .collect();

    let total = sizes.iter().sum::<f32>() + (n - 1) as f32 * m.gap + extra(n - 1);
    let mut x = (width - total) / 2.0;
    sizes
        .into_iter()
        .enumerate()
        .map(|(i, size)| {
            let slot = Slot { x, size, dx: 0.0 };
            x += size + m.gap;
            if seps.contains(&i) {
                x += m.sep;
            }
            slot
        })
        .collect()
}

/// Retângulo do fundo (esquerda, topo, direita, base), em pixels inteiros.
pub fn box_rect(slots: &[Slot], m: &Metrics, height: f32) -> Option<(i32, i32, i32, i32)> {
    let (first, last) = (slots.first()?, slots.last()?);
    let bottom = height - m.margin;
    Some((
        (first.x - m.pad).round() as i32,
        (bottom - m.base - 2.0 * m.pad).round() as i32,
        (last.x + last.size + m.pad).round() as i32,
        bottom.round() as i32,
    ))
}

#[derive(Clone, Copy)]
pub enum Direction {
    Bottom,
    Left,
    Right,
}

impl Direction {
    pub fn coords(self, x: f32, y: f32, cross: f32) -> (f32, f32) {
        match self {
            Self::Bottom => (x, y),
            Self::Left => (cross - y, x),
            Self::Right => (y, x),
        }
    }

    fn transform(self, cross: f32) -> Transform {
        match self {
            Self::Bottom => Transform::identity(),
            Self::Left => Transform::from_row(0.0, 1.0, -1.0, 0.0, cross, 0.0),
            Self::Right => Transform::from_row(0.0, 1.0, 1.0, 0.0, 0.0, 0.0),
        }
    }

    pub fn rect(self, l: i32, t: i32, r: i32, b: i32, cross: i32) -> (i32, i32, i32, i32) {
        match self {
            Self::Bottom => (l, t, r, b),
            Self::Left => (cross - b, l, cross - t, r),
            Self::Right => (t, l, b, r),
        }
    }
}

pub fn draw(
    pm: &mut Pixmap,
    slots: &[Slot],
    seps: &[usize],
    apps: &[&App],
    m: &Metrics,
    theme: &Theme,
    hover: f32,
    focus: Option<usize>,
    fast: bool,
) {
    draw_oriented(pm, slots, seps, apps, m, theme, hover, focus, fast, Direction::Bottom);
}

pub fn draw_oriented(
    pm: &mut Pixmap,
    slots: &[Slot],
    seps: &[usize],
    apps: &[&App],
    m: &Metrics,
    theme: &Theme,
    hover: f32,
    focus: Option<usize>,
    fast: bool,
    direction: Direction,
) {
    pm.fill(Color::TRANSPARENT);
    let cross = match direction { Direction::Bottom => pm.height(), _ => pm.width() } as f32;
    let Some((l, t, r, b)) = box_rect(slots, m, cross) else {
        return;
    };
    let (l, t, r, b) = (l as f32, t as f32, r as f32, b as f32);
    let icon_bottom = b - m.pad;
    let id = direction.transform(cross);

    // Área quase invisível acima do fundo: mantém o mouse "dentro" do dock enquanto há zoom
    // (pixels com alfa 0 deixam o clique passar para a janela de trás).
    if hover > 0.01 {
        if let Some(rect) = Rect::from_ltrb(l, 0.0, r, t) {
            pm.fill_rect(rect, &solid([0, 0, 0, 1]), id, None);
        }
    }

    // Vidro: o desfoque vem da janela de fundo; aqui só a tinta e a borda.
    if let Some(bg) = rounded_rect(l, t, r - l, b - t, m.radius) {
        pm.fill_path(&bg, &solid(theme.tint), FillRule::Winding, id, None);
    }
    if let Some(border) = rounded_rect(l + 0.5, t + 0.5, r - l - 1.0, b - t - 1.0, m.radius - 0.5) {
        let stroke = Stroke { width: 1.0, ..Default::default() };
        pm.stroke_path(&border, &solid(theme.border), &stroke, id, None);
    }

    for s in seps.iter().filter_map(|&s| slots.get(s)) {
        let x = (s.x + s.size + (m.gap + m.sep) / 2.0).round() + 0.5;
        if let Some(rect) = Rect::from_xywh(x - 0.5, t + m.pad * 1.3, 1.0, b - t - m.pad * 2.6) {
            pm.fill_rect(rect, &solid(theme.divider), id, None);
        }
    }

    // Bilinear nos quadros intermediários da animação (~2,5x mais barato); o quadro final sai em Bicubic.
    let quality = if fast { FilterQuality::Bilinear } else { FilterQuality::Bicubic };
    let icon_paint = PixmapPaint { quality, ..Default::default() };
    for (i, (slot, app)) in slots.iter().zip(apps).enumerate() {
        // Ícone arrastado: desenhado fora do lugar (o espaço dele continua no layout).
        let sx = slot.x + slot.dx;
        // App pedindo atenção: pula no espaço livre acima (até meio ícone).
        let (lift, alert) = crate::attention::state(&app.windows);
        let y = icon_bottom - slot.size;
        let y = y - lift * y.min(slot.size * 0.5);
        match &app.icon {
            // O ícone como ele é, ocupando o espaço do app (sem caixa por trás).
            Some(icon) => {
                let (iw, ih) = (icon.width() as f32, icon.height() as f32);
                let s = slot.size / iw.max(ih);
                let (cx, cy) = direction.coords(sx + slot.size / 2.0, y + slot.size / 2.0, cross);
                let ox = cx - iw * s / 2.0;
                let oy = cy - ih * s / 2.0;
                let tr = Transform::from_row(s, 0.0, 0.0, s, ox, oy);
                pm.draw_pixmap(0, 0, icon.as_ref(), &icon_paint, tr, None);
            }
            None => {
                if let Some(p) = rounded_rect(sx, y, slot.size, slot.size, slot.size * 0.22) {
                    pm.fill_path(&p, &solid([120, 120, 128, 220]), FillRule::Winding, id, None);
                }
            }
        }
        if alert {
            let r = m.dot * 2.5;
            if let Some(badge) = PathBuilder::from_circle(sx + slot.size - r, y + r, r) {
                pm.fill_path(&badge, &solid([255, 59, 48, 255]), FillRule::Winding, id, None);
            }
        }
        // macOS-style single running-app indicator; the focused app uses the system accent.
        if !app.windows.is_empty() {
            let color = if focus == Some(i) { theme.accent } else { theme.dot };
            let w = m.dot * 3.6;
            let h = m.dot * 1.5;
            let x = sx + slot.size / 2.0 - w / 2.0;
            let y = icon_bottom + m.pad / 2.0 + 0.5 - h / 2.0;
            if let Some(indicator) = rounded_rect(x, y, w, h, h / 2.0) {
                pm.fill_path(&indicator, &solid(color), FillRule::Winding, id, None);
            }
        }
    }
}

/// Colunas tocadas pelo fundo ou por ícones arrastados, incluindo a margem da suavização.
pub fn raster_columns(slots: &[Slot], rect: Option<(i32, i32, i32, i32)>, width: usize) -> std::ops::Range<usize> {
    let Some((l, _, r, _)) = rect else { return 0..0; };
    let mut left = l as f32;
    let mut right = r as f32;
    for s in slots {
        left = left.min(s.x + s.dx);
        right = right.max(s.x + s.dx + s.size);
    }
    let clamp = |x: i32| x.clamp(0, width as i32) as usize;
    clamp(left.floor() as i32 - 2)..clamp(right.ceil() as i32 + 2)
}

fn solid([r, g, b, a]: [u8; 4]) -> Paint<'static> {
    let mut p = Paint::default();
    p.set_color_rgba8(r, g, b, a);
    p.anti_alias = true;
    p
}

fn rounded_rect(x: f32, y: f32, w: f32, h: f32, r: f32) -> Option<tiny_skia::Path> {
    let r = r.min(w / 2.0).min(h / 2.0);
    // Constante de Bézier para quartos de círculo.
    let k = r * 0.5523;
    let mut pb = PathBuilder::new();
    pb.move_to(x + r, y);
    pb.line_to(x + w - r, y);
    pb.cubic_to(x + w - r + k, y, x + w, y + r - k, x + w, y + r);
    pb.line_to(x + w, y + h - r);
    pb.cubic_to(x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h);
    pb.line_to(x + r, y + h);
    pb.cubic_to(x + r - k, y + h, x, y + h - r + k, x, y + h - r);
    pb.line_to(x, y + r);
    pb.cubic_to(x, y + r - k, x + r - k, y, x + r, y);
    pb.close();
    pb.finish()
}
