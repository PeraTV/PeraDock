[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'

if (-not (Get-Command cargo.exe -ErrorAction SilentlyContinue)) {
    throw 'Instale Rust pelo rustup e abra um novo PowerShell. Consulte https://rust-lang.org/install.'
}
Push-Location -LiteralPath $PSScriptRoot
try {
    & cargo.exe build --locked --release
    if ($LASTEXITCODE -ne 0) { throw "A compilação terminou com erro $LASTEXITCODE." }
    $binary = Join-Path $PSScriptRoot 'target\release\arcdockwin.exe'
    if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) {
        throw 'A compilação não criou target\release\arcdockwin.exe.'
    }
    Copy-Item -LiteralPath $binary -Destination (Join-Path $PSScriptRoot 'PeraDock.exe') -Force
    'PeraDock.exe criado nesta pasta.'
} finally { Pop-Location }
