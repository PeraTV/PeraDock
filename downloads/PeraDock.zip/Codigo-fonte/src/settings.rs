//! Janela de Configurações do ArcDockWin: janela normal do Windows (barra de título, Alt+Tab,
//! ícone no dock) com fundo Mica, barra lateral de seções e cartões à direita. O desenho usa
//! o mesmo kit dos painéis (`panel.rs`): paleta, texto, interruptor e controle deslizante.
//! As opções ficam em `config.rs` (a animação em `animcfg.rs`) e valem na hora.

use std::cell::RefCell;
use std::ffi::c_void;
use std::sync::atomic::{AtomicIsize, Ordering};

use tiny_skia::{PixmapMut, Rect, Stroke, Transform};
use windows::Win32::Foundation::{HINSTANCE, HWND, LPARAM, LRESULT, POINT, RECT, WPARAM};
use windows::Win32::Graphics::Dwm::{
    DWMSBT_MAINWINDOW, DWMWA_SYSTEMBACKDROP_TYPE, DWMWA_USE_IMMERSIVE_DARK_MODE, DWMWA_WINDOW_CORNER_PREFERENCE,
    DWMWCP_ROUND, DwmExtendFrameIntoClientArea, DwmSetWindowAttribute,
};
use windows::Win32::Graphics::DirectWrite::{
    DWRITE_TEXT_ALIGNMENT, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_TEXT_ALIGNMENT_TRAILING,
};
use windows::Win32::Graphics::Gdi::{
    BeginPaint, BitBlt, EndPaint, GetMonitorInfoW, InvalidateRect, MONITOR_DEFAULTTONEAREST, MONITORINFO,
    MonitorFromPoint, MonitorFromWindow, PAINTSTRUCT, SRCCOPY, ScreenToClient,
};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::MARGINS;
use windows::Win32::UI::HiDpi::{AdjustWindowRectExForDpi, GetDpiForMonitor, GetDpiForWindow, MDT_EFFECTIVE_DPI};
use windows::Win32::UI::Input::KeyboardAndMouse::{
    GetKeyState, ReleaseCapture, SetCapture, TME_LEAVE, TRACKMOUSEEVENT, TrackMouseEvent, VK_DOWN, VK_LEFT, VK_RETURN,
    VK_RIGHT, VK_SHIFT, VK_SPACE, VK_TAB, VK_UP,
};
use windows::Win32::UI::Shell::ShellExecuteW;
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::core::{BOOL, HSTRING, w};

use crate::animcfg::{self, Effect};
use crate::config::{self, Module, Slot, Zone as BarZone};
use crate::i18n::tr;
use crate::panel::{self, Buffer, Font, Palette, Text, TextOp, WHITE, paint, rgba};
use crate::topbar::rounded_rect;

const WM_UPDATE_DONE: u32 = WM_APP + 90;
const RELEASE: u32 = 9;
const DOWNLOADS: &str = "https://github.com/PeraTV/PeraDock/releases";
static CHECKING: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
const WM_MOUSELEAVE: u32 = 0x02A3;
/// Área interna da janela e largura da barra lateral (px antes da escala).
const WIDTH: f32 = 820.0;
const HEIGHT: f32 = 620.0;
const TAB_BAR: f32 = 48.0;
const TITLEBAR: f32 = 38.0;
const ROW: f32 = 60.0;
/// Linhas mais baixas na página da barra do topo (cabe tudo sem rolagem).
const ROW_COMPACT: f32 = 48.0;
const BAR_PAGE: usize = 2;
const SIDE_PAGE: usize = 4;
const CARD_RADIUS: f32 = 16.0;

/// Seções da barra lateral: nome e glifo (Segoe Fluent Icons).
const PAGES: [(&str, u16); 5] = [("Dock", 0xE71D), ("Animações", 0xE768), ("Barra do topo", 0xE7F4), ("Geral", 0xE713), ("Dock 2", 0xE8A7)];

#[derive(Clone, Copy, PartialEq)]
enum Opt {
    IconSize,
    Magnify,
    MagnifySize,
    AutoHide,
    Stacks,
    DockAllMonitors,
    Previews,
    Anim,
    Clock24,
    ClockSeconds,
    ClockDate,
    AllMonitors,
    Autostart,
    ControlsOnRight,
    SideEnabled,
    DockNames,
    SideNames,
    SideTransparency,
    SideIconSize,
    SideBorder,
    DockBorder,
    DockEnabled,
    SideAutoHide,
    SideAnimate,
}

/// O que uma área clicável faz.
#[derive(Clone, Copy, PartialEq)]
enum Act {
    Page(usize),
    Toggle(Opt),
    /// Trilho do controle deslizante: x inicial e final.
    Slider(Opt, f32, f32),
    Effect(Effect),
    Window(u32),
    CheckUpdates,
    Exit,
    SideAdd,
    DockPosition(bool),
    SideColor,
    SideColorReset,
    /// Módulo da barra do topo: liga/desliga, zona, sobe (-1) ou desce (+1).
    ModOn(Module),
    ModZone(Module, BarZone),
    ModMove(Module, i32),
}

enum Row {
    Toggle(Opt, &'static str, bool),
    /// Opção, texto, valor (0..1), rótulo do valor, habilitado.
    Slider(Opt, &'static str, f32, String, bool),
    /// Gênio/Escala; habilitado.
    Effect(bool),
    Info(&'static str, String),
    Color(Option<[u8; 3]>),
    Action(&'static str, &'static str, Act),
    /// Módulo da barra; pode subir / descer dentro da zona.
    Module(Slot, bool, bool),
}

enum Block {
    Label(&'static str),
    Card(Vec<Row>),
    /// Esquema da barra do topo: as três zonas com os módulos visíveis.
    Preview,
}

struct Zone {
    r: [f32; 4],
    radius: f32,
    act: Act,
}

struct Win {
    hwnd: HWND,
    scale: f32,
    text: Text,
    buf: Option<Buffer>,
    page: usize,
    zones: Vec<Zone>,
    hot: Option<usize>,
    pressed: Option<usize>,
    /// Arrastando um controle deslizante: opção e trilho.
    drag: Option<(Opt, f32, f32)>,
    /// Área com o foco do teclado (só aparece depois do Tab).
    focus: Option<usize>,
    tracking: bool,
}

thread_local! {
    static WIN: RefCell<Option<Win>> = const { RefCell::new(None) };
}

/// Janela aberta (HWND como número; 0 = fechada), para o dock listá-la como app.
static HWND_OPEN: AtomicIsize = AtomicIsize::new(0);

pub fn hwnd() -> HWND {
    HWND(HWND_OPEN.load(Ordering::Relaxed) as *mut c_void)
}

fn with_win<R>(f: impl FnOnce(&mut Win) -> R) -> Option<R> {
    // try_borrow_mut: chamadas do Windows podem reentrar no wndproc.
    WIN.with(|w| w.try_borrow_mut().ok().and_then(|mut g| g.as_mut().map(f)))
}

/// Valor (0..1) de um controle deslizante.
fn value(o: Opt) -> f32 {
    match o {
        Opt::SideIconSize => (config::side_icon_size() - 32.0) / 40.0,
        Opt::IconSize => (config::icon_size() - 32.0) / 40.0,
        Opt::MagnifySize => (config::magnify_scale() - 1.1) / 0.9,
        Opt::SideTransparency => config::side_transparency() / 90.0,
        _ => 0.0,
    }
}

/// Passo do teclado em cada controle deslizante (1 px; 0,05×).
fn step(o: Opt) -> f32 {
    match o { Opt::IconSize | Opt::SideIconSize => 1.0 / 40.0, Opt::SideTransparency => 1.0 / 90.0, _ => 0.05 / 0.9 }
}

/// Muda um controle deslizante e aplica no dock; `reload`: recarrega os ícones (fim do arrasto).
fn slide(o: Opt, v: f32, reload: bool) {
    let v = v.clamp(0.0, 1.0);
    if o == Opt::SideIconSize {
        let size = (32.0 + v * 40.0).round();
        if size != config::side_icon_size() {
            config::set_side_icon_size(size);
            crate::side_dock::sync();
        }
        return;
    }
    if o == Opt::SideTransparency {
        let percent = (90.0 * v).round();
        if percent != config::side_transparency() {
            config::set_side_transparency(percent);
            crate::side_dock::refresh_appearance();
        }
        return;
    }
    let changed = match o {
        Opt::IconSize => {
            let px = (32.0 + v * 40.0).round();
            let changed = px != config::icon_size();
            if changed {
                config::set_icon_size(px);
            }
            changed
        }
        Opt::MagnifySize => {
            let x = ((1.1 + v * 0.9) * 20.0).round() / 20.0;
            let changed = (x - config::magnify_scale()).abs() > 0.001;
            if changed {
                config::set_magnify_scale(x);
            }
            changed
        }
        _ => false,
    };
    if changed || reload {
        crate::apply_settings(reload);
    }
}

fn toggle(o: Opt) {
    match o {
        Opt::Magnify => {
            config::set_magnify(!config::magnify());
            crate::apply_settings(true);
        }
        Opt::AutoHide => {
            config::set_autohide(!config::autohide());
            crate::apply_settings(false);
        }
        Opt::Stacks => {
            config::set_stacks(!config::stacks());
            crate::apply_settings(false);
        }
        Opt::DockAllMonitors => {
            config::set_dock_all_monitors(!config::dock_all_monitors());
            crate::rebuild_docks();
        }
        Opt::Previews => {
            config::set_window_previews(!config::window_previews());
            crate::preview::dismiss();
        }
        Opt::Anim => {
            animcfg::set_enabled(!animcfg::enabled());
            crate::minimize::config_changed();
        }
        Opt::Clock24 => {
            config::set_clock_24h(!config::clock_24h());
            crate::topbar::settings_changed();
        }
        Opt::ClockSeconds => {
            config::set_clock_seconds(!config::clock_seconds());
            crate::topbar::settings_changed();
        }
        Opt::ClockDate => {
            config::set_clock_date(!config::clock_date());
            crate::topbar::settings_changed();
        }
        Opt::AllMonitors => {
            config::set_bar_all_monitors(!config::bar_all_monitors());
            crate::topbar::monitors_changed();
        }
        Opt::Autostart => {
            config::set_autostart(!config::autostart());
            crate::autostart();
        }
        Opt::SideEnabled => { config::set_side_enabled(!config::side_enabled()); crate::side_dock::sync(); }
        Opt::SideAnimate => { config::set_side_animate(!config::side_animate()); crate::side_dock::sync(); }
        Opt::DockNames => config::toggle_dock_names(false),
        Opt::SideNames => config::toggle_dock_names(true),
        Opt::ControlsOnRight => config::set_controls_on_right(!config::controls_on_right()),
        Opt::DockEnabled => {
            config::set_dock_enabled(!config::dock_enabled());
            crate::apply_dock_mode();
        }
        Opt::DockBorder => {
            config::set_dock_border(!config::dock_border());
            crate::apply_settings(false);
        }
        Opt::SideBorder => {
            config::set_side_border(!config::side_border());
            crate::side_dock::refresh_appearance();
        }
        Opt::SideAutoHide => {
            config::set_side_autohide(!config::side_autohide());
            crate::side_dock::sync();
        }
        Opt::IconSize | Opt::MagnifySize | Opt::SideTransparency | Opt::SideIconSize => {}
    }
}

/// Executa uma ação fora do empréstimo da janela (as ações mexem no dock e na barra).
pub fn refresh() {
    with_win(|w| w.redraw());
}

fn select_edge(side: bool) {
    use crate::render::Direction;
    unsafe {
        let Ok(menu) = CreatePopupMenu() else { return };
        for (i,edge) in Direction::ALL.into_iter().enumerate() {
            let flags = if edge == config::dock_edge(side) { MF_CHECKED } else { MF_STRING };
            let _ = AppendMenuW(menu, flags, i + 1, &HSTRING::from(edge.label()));
        }
        let mut cursor = POINT::default();
        let _ = GetCursorPos(&mut cursor);
        let choice = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON, cursor.x,cursor.y,None,hwnd(),None).0;
        let _ = DestroyMenu(menu);
        if choice > 0 && let Some(edge)=Direction::ALL.get(choice as usize-1) {
            crate::move_dock(side,*edge);
        }
    }
}

fn run(act: Act) {
    match act {
        Act::Page(i) => {
            with_win(|w| w.page = i);
        }
        Act::Toggle(o) => toggle(o),
        Act::Effect(e) => {
            animcfg::set_effect(e);
            crate::minimize::config_changed();
        }
        Act::CheckUpdates => check_updates(),
        Act::ModOn(m) => {
            config::set_module_on(m, !config::module_on(m));
            crate::topbar::settings_changed();
        }
        Act::ModZone(m, z) => {
            config::set_module_zone(m, z);
            crate::topbar::settings_changed();
        }
        Act::ModMove(m, dir) => {
            config::move_module(m, dir);
            crate::topbar::settings_changed();
        }
        Act::Window(command) => unsafe {
            let window = hwnd();
            let command = if command == SC_MAXIMIZE && IsZoomed(window).as_bool() { SC_RESTORE } else { command };
            let _ = PostMessageW(Some(window), WM_SYSCOMMAND, WPARAM(command as usize), LPARAM(0));
        },
        Act::Exit => crate::exit_application(),
        Act::SideAdd => crate::side_dock::add(hwnd()),
        Act::DockPosition(side) => select_edge(side),
        Act::SideColor => crate::side_dock::pick_color(hwnd()),
        Act::SideColorReset => {
            config::set_side_color(None);
            crate::side_dock::refresh_appearance();
        }
        Act::Slider(..) => {}
    }
}

fn check_updates() {
    let window = hwnd().0 as isize;
    if CHECKING.swap(true, Ordering::AcqRel) { return; }
    std::thread::spawn(move || {
        let revision = crate::usage::http_get(w!("api.github.com"), w!("/repos/PeraTV/PeraDock/releases/latest"),
            "Accept: application/vnd.github+json\r\n")
            .and_then(|(code, body)| {
                if code != 200 { return None; }
                let metadata: serde_json::Value = serde_json::from_slice(&body).ok()?;
                let revision: u32 = metadata["tag_name"].as_str()?.strip_prefix('r')?.parse().ok()?;
                (revision > 0).then_some(revision)
            });
        CHECKING.store(false, Ordering::Release);
        let target = hwnd();
        if target.0 as isize == window {
            unsafe {
                let _ = PostMessageW(Some(target), WM_UPDATE_DONE, WPARAM(revision.unwrap_or(0) as usize),
                    LPARAM(isize::from(revision.is_some())));
            }
        }
    });
}

fn update_done(hwnd: HWND, revision: u32, ok: bool) {
    with_win(|w| w.redraw());
    let (notice, buttons) = if !ok {
        ("Não foi possível consultar o GitHub. Tente novamente em instantes.".to_string(), MB_OK | MB_ICONINFORMATION)
    } else if revision > RELEASE {
        (format!("A versão R{revision} está disponível. Abrir a página de download?"), MB_YESNO | MB_ICONINFORMATION)
    } else {
        (format!("Você já está com a versão mais recente (R{RELEASE})."), MB_OK | MB_ICONINFORMATION)
    };
    unsafe {
        if MessageBoxW(Some(hwnd), &HSTRING::from(notice), w!("Atualizações do PeraDock"), buttons) == IDYES {
            let url = HSTRING::from(format!("{DOWNLOADS}/tag/r{revision}"));
            ShellExecuteW(Some(hwnd), w!("open"), &url, None, None, SW_SHOWNORMAL);
        }
    }
}

/// Número com vírgula em pt-BR.
fn decimal(v: f32) -> String {
    let s = format!("{v:.2}");
    if crate::i18n::is_traditional_chinese() || crate::i18n::is_english() { s } else { s.replace('.', ",") }
}

/// Conteúdo da seção `page`.
fn blocks(page: usize) -> Vec<Block> {
    match page {
        0 => {
            let zoom = config::magnify();
            vec![Block::Card(vec![
                Row::Slider(Opt::IconSize, "Tamanho dos ícones", value(Opt::IconSize), format!("{} px", config::icon_size()), true),
                Row::Toggle(Opt::DockEnabled, "Mostrar Dock 1 no lugar da barra do Windows", config::dock_enabled()),
                Row::Action("Posição da Dock 1", config::dock_edge(false).label(), Act::DockPosition(false)),
                Row::Toggle(Opt::DockNames, "Mostrar nome dos aplicativos", config::dock_show_names(false)),
                Row::Toggle(Opt::DockBorder, "Mostrar contorno da Dock 1", config::dock_border()),
                Row::Toggle(Opt::Magnify, "Ampliação ao passar o mouse", zoom),
                Row::Slider(Opt::MagnifySize, "Tamanho da ampliação", value(Opt::MagnifySize), format!("{}×", decimal(config::magnify_scale())), zoom),
                Row::Toggle(Opt::AutoHide, "Ocultar automaticamente", config::autohide()),
                Row::Toggle(Opt::Stacks, "Mostrar Downloads e Lixeira", config::stacks()),
                Row::Toggle(Opt::Previews, "Prévia das janelas ao passar o mouse", config::window_previews()),
                Row::Toggle(Opt::DockAllMonitors, "Mostrar Dock em todos os monitores", config::dock_all_monitors()),
            ])]
        }
        1 => {
            let on = animcfg::enabled();
            vec![Block::Card(vec![Row::Toggle(Opt::Anim, "Animação ao minimizar janelas", on), Row::Effect(on)])]
        }
        BAR_PAGE => {
            // Ordem da lista = ordem na barra, da esquerda para a direita.
            let list = config::modules();
            let rows = list
                .iter()
                .enumerate()
                .map(|(i, s)| {
                    let up = i > 0 && list[i - 1].zone == s.zone;
                    let down = list.get(i + 1).is_some_and(|n| n.zone == s.zone);
                    Row::Module(*s, up, down)
                })
                .collect();
            vec![
                Block::Preview,
                Block::Card(rows),
                Block::Label("Relógio"),
                Block::Card(vec![
                    Row::Toggle(Opt::Clock24, "Formato de 24 horas", config::clock_24h()),
                    Row::Toggle(Opt::ClockSeconds, "Mostrar segundos", config::clock_seconds()),
                    Row::Toggle(Opt::ClockDate, "Mostrar a data", config::clock_date()),
                ]),
                Block::Card(vec![Row::Toggle(Opt::AllMonitors, "Mostrar em todos os monitores", config::bar_all_monitors())]),
            ]
        }
        SIDE_PAGE => vec![Block::Card(vec![
            Row::Toggle(Opt::SideEnabled, "Mostrar Dock 2", config::side_enabled()),
            Row::Action("Posição da Dock 2", config::dock_edge(true).label(), Act::DockPosition(true)),
            Row::Toggle(Opt::SideNames, "Mostrar nome dos aplicativos", config::dock_show_names(true)),
            Row::Slider(Opt::SideIconSize, "Tamanho dos ícones da Dock 2", value(Opt::SideIconSize), format!("{} px", config::side_icon_size()), true),
            Row::Toggle(Opt::SideBorder, "Mostrar contorno da Dock 2", config::side_border()),
            Row::Color(config::side_color()),
            Row::Toggle(Opt::SideAutoHide, "Ocultar ao usar outro aplicativo", config::side_autohide()),
            Row::Slider(Opt::SideTransparency, "Transparência do fundo", value(Opt::SideTransparency), format!("{}%", config::side_transparency()), true),
            Row::Toggle(Opt::SideAnimate, "Animar os ícones ao passar o mouse", config::side_animate()),
            Row::Action("Arraste um aplicativo ou atalho", "Adicionar aplicativo…", Act::SideAdd),
            Row::Info("Atalhos nesta dock", crate::side_dock::count().to_string()),
        ])],
        _ => vec![
            Block::Card(vec![Row::Toggle(Opt::Autostart, "Iniciar com o Windows", config::autostart())]),
            Block::Card(vec![
                Row::Toggle(Opt::ControlsOnRight, "Semáforo à direita nas Configurações", config::controls_on_right()),
            ]),
            Block::Label("Sobre"),
            Block::Card(vec![
                Row::Info("PeraDock", String::new()),
                Row::Action("Verificar atualizações", if CHECKING.load(Ordering::Relaxed) { "Verificando…" } else { "Verificar" }, Act::CheckUpdates),
                Row::Action("Restaurar a barra de tarefas do Windows", "Sair do PeraDock", Act::Exit),
            ]),
        ],
    }
}

impl Win {
    fn redraw(&mut self) {
        let mut rc = RECT::default();
        unsafe {
            let _ = GetClientRect(self.hwnd, &mut rc);
        }
        let (bw, bh) = (rc.right, rc.bottom);
        if bw <= 0 || bh <= 0 {
            return;
        }
        if self.buf.as_ref().is_none_or(|b| b.w != bw || b.h != bh) {
            self.buf = None;
            self.buf = Buffer::new(bw, bh);
        }
        let Some(buf) = &self.buf else { return };
        let (memdc, bits) = (buf.memdc, buf.bits);
        let s = self.scale;
        let mut pal = Palette::new();
        let light = crate::light_theme();
        let header = if light { [238, 229, 247, 255] } else { [48, 31, 65, 255] };
        let background = if light { [249, 245, 251, 255] } else { [27, 21, 39, 255] };
        pal.accent = if light { [118, 62, 152, 255] } else { [155, 98, 190, 255] };
        pal.card = if light { [255, 255, 255, 255] } else { [43, 33, 57, 255] };
        // Fundo transparente: o Mica aparece por trás (moldura estendida sobre a janela toda).
        let bytes = unsafe { std::slice::from_raw_parts_mut(bits, (bw * bh * 4) as usize) };
        bytes.fill(0);
        let Some(mut pm) = PixmapMut::from_bytes(bytes, bw as u32, bh as u32) else { return };
        let tf = Transform::identity();
        let fill = |pm: &mut PixmapMut, [x, y, w, h]: [f32; 4], r: f32, c: [u8; 4]| {
            if let Some(p) = rounded_rect(x, y, w, h, r) {
                pm.fill_path(&p, &paint(c), tiny_skia::FillRule::Winding, tf, None);
            }
        };
        let stroke = |pm: &mut PixmapMut, [x, y, w, h]: [f32; 4], r: f32, c: [u8; 4], width: f32| {
            if let Some(p) = rounded_rect(x, y, w, h, r) {
                pm.stroke_path(&p, &paint(c), &Stroke { width, ..Default::default() }, tf, None);
            }
        };
        let mut texts: Vec<TextOp> = Vec::new();
        let mut text = |t: &str, font: Font, rect: [f32; 4], align: DWRITE_TEXT_ALIGNMENT, color: [f32; 4]| {
            texts.push(TextOp { text: t.encode_utf16().collect(), font, rect, align, color, wrap: false, clip: None });
        };
        let glyph = |g: u16| String::from_utf16_lossy(&[g]);
        let (lead, trail, center) = (DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_TEXT_ALIGNMENT_TRAILING, DWRITE_TEXT_ALIGNMENT_CENTER);
        let mut zones = Vec::new();

        pm.fill(tiny_skia::Color::from_rgba8(background[2],background[1],background[0],255));
        fill(&mut pm, [0.0,0.0,bw as f32,(TITLEBAR + TAB_BAR)*s], 0.0, header);
        let tab_width = ((bw as f32 - 40.0 * s) / PAGES.len() as f32).min(152.0 * s);
        let tab_start = (bw as f32 - PAGES.len() as f32 * tab_width) / 2.0;
        for (i, &(name, g)) in PAGES.iter().enumerate() {
            let r = [tab_start + i as f32 * tab_width + 2.0 * s, (TITLEBAR + 4.0) * s, tab_width - 4.0 * s, 36.0 * s];
            let tab_ink = if i == self.page { fill(&mut pm, r, 18.0 * s, pal.accent); WHITE } else { pal.ink };
            zones.push(Zone { r, radius: 6.0 * s, act: Act::Page(i) });
            text(&glyph(g), Font::Icon, [r[0] + 12.0 * s, r[1], 20.0 * s, r[3]], center, tab_ink);
            text(&tr(name), Font::Body, [r[0] + 44.0 * s, r[1], r[2] - 52.0 * s, r[3]], lead, tab_ink);
        }

        // Conteúdo: título da seção e cartões.
        let (cx, cr) = (30.0 * s, bw as f32 - 30.0 * s);
        let cw = cr - cx;
        text(&tr(PAGES[self.page].0), Font::Header, [cx + 4.0 * s, (TITLEBAR + TAB_BAR + 5.0) * s, cw, 48.0 * s], lead, pal.ink);
        let mut y = (TITLEBAR + TAB_BAR + 59.0) * s;
        for block in blocks(self.page) {
            let rows = match block {
                Block::Label(t) => {
                    text(&tr(t), Font::Bold, [cx + 4.0 * s, y + 8.0 * s, cw, 24.0 * s], lead, pal.ink);
                    y += 36.0 * s;
                    continue;
                }
                Block::Preview => {
                    preview(&mut pm, &mut text, &pal, [cx, y, cw, 44.0 * s], s);
                    y += 44.0 * s + 16.0 * s;
                    continue;
                }
                Block::Card(rows) => rows,
            };
            let rh = if matches!(self.page, 0 | BAR_PAGE | SIDE_PAGE) { ROW_COMPACT } else { ROW } * s;
            let card = [cx, y, cw, rows.len() as f32 * rh];
            fill(&mut pm, card, CARD_RADIUS * s, pal.card);
            stroke(&mut pm, [cx + 0.5, y + 0.5, cw - 1.0, card[3] - 1.0], CARD_RADIUS * s - 0.5, pal.card_line, 1.0);
            for (k, row) in rows.iter().enumerate() {
                let ry = y + k as f32 * rh;
                if k > 0
                    && let Some(line) = Rect::from_xywh(cx + 16.0 * s, ry, cw - 32.0 * s, 1.0)
                {
                    pm.fill_rect(line, &paint(pal.line), tf, None);
                }
                let (lx, rx, cy) = (cx + 18.0 * s, cr - 18.0 * s, ry + rh / 2.0);
                let label = [lx, ry, rx - lx, rh];
                let whole = [cx + 4.0 * s, ry + 4.0 * s, cw - 8.0 * s, rh - 8.0 * s];
                match row {
                    Row::Toggle(o, t, on) => {
                        let sx = panel::switch(&mut pm, tf, &pal, rx, cy, s, *on);
                        zones.push(Zone { r: whole, radius: 8.0 * s, act: Act::Toggle(*o) });
                        text(&tr(t), Font::Body, [lx, ry, sx - lx - 8.0 * s, rh], lead, pal.ink);
                    }
                    Row::Slider(o, t, v, value, on) => {
                        let vw = 64.0 * s;
                        let (tl, tr_) = (rx - vw - 16.0 * s - 220.0 * s, rx - vw - 16.0 * s);
                        let color = if *on { pal.accent } else { pal.strong };
                        panel::slider(&mut pm, tf, &pal, tl, tr_, cy, s, v.clamp(0.0, 1.0), color);
                        if *on {
                            let r = [tl - 10.0 * s, ry, tr_ - tl + 20.0 * s, rh];
                            zones.push(Zone { r, radius: 0.0, act: Act::Slider(*o, tl, tr_) });
                        }
                        let ink = if *on { pal.ink } else { pal.dim };
                        text(&tr(t), Font::Body, [lx, ry, tl - lx - 16.0 * s, rh], lead, ink);
                        text(value, Font::Body, [rx - vw, ry, vw, rh], trail, ink);
                    }
                    Row::Effect(on) => {
                        let (sw, sh) = (100.0 * s, 30.0 * s);
                        let x0 = rx - 2.0 * sw;
                        fill(&mut pm, [x0, cy - sh / 2.0, 2.0 * sw, sh], 8.0 * s, pal.control);
                        for (i, e) in Effect::ALL.into_iter().enumerate() {
                            let r = [x0 + i as f32 * sw, cy - sh / 2.0, sw, sh];
                            let selected = e == animcfg::effect();
                            if selected {
                                let c = if *on { pal.accent } else { pal.strong };
                                fill(&mut pm, [r[0] + 3.0 * s, r[1] + 3.0 * s, sw - 6.0 * s, sh - 6.0 * s], 6.0 * s, c);
                            } else if *on {
                                zones.push(Zone { r, radius: 8.0 * s, act: Act::Effect(e) });
                            }
                            let ink = match (*on, selected) {
                                (true, true) => WHITE,
                                (true, false) => pal.ink,
                                _ => pal.dim,
                            };
                            text(&tr(e.label()), Font::Body, r, center, ink);
                        }
                        text(&tr("Efeito"), Font::Body, [lx, ry, x0 - lx - 8.0 * s, rh], lead, if *on { pal.ink } else { pal.dim });
                    }
                    Row::Module(slot, up, down) => {
                        let m = slot.module;
                        let sx = panel::switch(&mut pm, tf, &pal, rx, cy, s, slot.on);
                        zones.push(Zone { r: [sx - 4.0 * s, cy - 14.0 * s, rx - sx + 8.0 * s, 28.0 * s], radius: 14.0 * s, act: Act::ModOn(m) });
                        // Setas ▲ ▼: trocam com o vizinho da mesma zona.
                        let bw = 28.0 * s;
                        let mut bx = sx - 14.0 * s - 2.0 * bw - 4.0 * s;
                        for (dir, g, enabled) in [(-1, 0xE70E, *up), (1, 0xE70D, *down)] {
                            let r = [bx, cy - bw / 2.0, bw, bw];
                            fill(&mut pm, r, 6.0 * s, pal.control);
                            if enabled {
                                zones.push(Zone { r, radius: 6.0 * s, act: Act::ModMove(m, dir) });
                            }
                            let ink = if enabled { pal.ink } else { [pal.dim[0], pal.dim[1], pal.dim[2], pal.dim[3] * 0.5] };
                            text(&glyph(g), Font::Icon, r, center, ink);
                            bx += bw + 4.0 * s;
                        }
                        // Zona: Esquerda | Centro | Direita.
                        let (sw, sh) = (78.0 * s, 28.0 * s);
                        let x0 = sx - 14.0 * s - 2.0 * bw - 4.0 * s - 12.0 * s - 3.0 * sw;
                        fill(&mut pm, [x0, cy - sh / 2.0, 3.0 * sw, sh], 8.0 * s, pal.control);
                        for (i, z) in BarZone::ALL.into_iter().enumerate() {
                            let r = [x0 + i as f32 * sw, cy - sh / 2.0, sw, sh];
                            let selected = z == slot.zone;
                            if selected {
                                let c = if slot.on { pal.accent } else { pal.strong };
                                fill(&mut pm, [r[0] + 3.0 * s, r[1] + 3.0 * s, sw - 6.0 * s, sh - 6.0 * s], 6.0 * s, c);
                            } else {
                                zones.push(Zone { r, radius: 8.0 * s, act: Act::ModZone(m, z) });
                            }
                            text(&tr(z.label()), Font::Body, r, center, if selected { WHITE } else { pal.ink });
                        }
                        let ink = if slot.on { pal.ink } else { pal.dim };
                        text(&tr(m.label()), Font::Body, [lx, ry, x0 - lx - 8.0 * s, rh], lead, ink);
                    }
                    Row::Info(t, v) => {
                        text(t, Font::Bold, label, lead, pal.ink);
                        text(v, Font::Body, label, trail, pal.dim);
                    }
                    Row::Color(color) => {
                        text("Cor do fundo", Font::Body, label, lead, pal.ink);
                        let choose = [rx - 122.0 * s, ry + 6.0 * s, 122.0 * s, rh - 12.0 * s];
                        fill(&mut pm, choose, 8.0 * s, pal.control);
                        if let Some([r, g, b]) = *color {
                            fill(&mut pm, [choose[0] + 9.0 * s, ry + rh / 2.0 - 7.0 * s, 14.0 * s, 14.0 * s], 3.0 * s, [r, g, b, 255]);
                            let reset = [choose[0] - 105.0 * s, choose[1], 100.0 * s, choose[3]];
                            text("Restaurar", Font::Body, reset, center, rgba(pal.accent));
                            zones.push(Zone { r: reset, radius: 8.0 * s, act: Act::SideColorReset });
                        }
                        let name = color.map_or_else(|| "Escolher".to_string(), |[r, g, b]| format!("#{r:02X}{g:02X}{b:02X}"));
                        text(&name, Font::Bold, [choose[0] + 20.0 * s, choose[1], choose[2] - 20.0 * s, choose[3]], center, rgba(pal.accent));
                        zones.push(Zone { r: choose, radius: 8.0 * s, act: Act::SideColor });
                    }
                    Row::Action(t, v, action) => {
                        zones.push(Zone { r: whole, radius: 10.0 * s, act: *action });
                        text(&tr(t), Font::Body, label, lead, pal.ink);
                        text(&tr(v), Font::Bold, label, trail, rgba(pal.accent));
                    }
                }
            }
            y += card[3] + 16.0 * s;
        }

        let right = config::controls_on_right();
        let x = if right { bw as f32 - 76.0 * s } else { 16.0 * s };
        let actions = if right { [SC_MINIMIZE, SC_MAXIMIZE, SC_CLOSE] } else { [SC_CLOSE, SC_MINIMIZE, SC_MAXIMIZE] };
        for (index, command) in actions.into_iter().enumerate() {
            let r = [x + index as f32 * 21.0 * s, 11.0 * s, 15.0 * s, 15.0 * s];
            let (color, mark) = match command {
                SC_MINIMIZE => ([255, 190, 54, 255], "−"),
                SC_MAXIMIZE => ([43, 198, 74, 255], "+"),
                _ => ([255, 94, 89, 255], "×"),
            };
            if let Some(circle) = tiny_skia::PathBuilder::from_circle(r[0] + r[2] / 2.0, r[1] + r[3] / 2.0, r[2] / 2.0) {
                pm.fill_path(&circle, &paint(color), tiny_skia::FillRule::Winding, tf, None);
            }
            if self.hot == Some(zones.len()) || self.focus == Some(zones.len()) {
                text(mark, Font::Bold, r, center, [0.2, 0.2, 0.2, 1.0]);
            }
            zones.push(Zone { r, radius: 7.5 * s, act: Act::Window(command) });
        }
        text("Configurações do PeraDock", Font::Bold, [95.0 * s, 0.0, bw as f32 - 190.0 * s, TITLEBAR * s], center, pal.ink);

        // Realce do mouse (menos na seção atual e nos controles deslizantes) e anel do foco.
        if let Some(z) = self.hot.and_then(|i| zones.get(i))
            && !matches!(z.act, Act::Slider(..))
            && z.act != Act::Page(self.page)
        {
            fill(&mut pm, z.r, z.radius, pal.hover);
        }
        if let Some(z) = self.focus.and_then(|i| zones.get(i)) {
            let [x, y, w, h] = z.r;
            let ink = pal.ink.map(|v| (v * 255.0) as u8);
            stroke(&mut pm, [x - 1.0 * s, y - 1.0 * s, w + 2.0 * s, h + 2.0 * s], z.radius + 1.0 * s, ink, 2.0 * s);
        }
        self.zones = zones;
        drop(pm);
        self.text.draw(memdc, bw, bh, &texts);
        unsafe {
            let _ = InvalidateRect(Some(self.hwnd), None, false);
        }
    }

    fn hit(&self, lp: LPARAM) -> (f32, Option<usize>) {
        let (x, y) = ((lp.0 & 0xffff) as i16 as f32, ((lp.0 >> 16) & 0xffff) as i16 as f32);
        let i = self.zones.iter().position(|z| x >= z.r[0] && x < z.r[0] + z.r[2] && y >= z.r[1] && y < z.r[1] + z.r[3]);
        (x, i)
    }

    /// Valor (0..1) do controle deslizante arrastado com o mouse em `x`.
    fn drag_value(&self, x: f32) -> Option<(Opt, f32)> {
        let (o, l, r) = self.drag?;
        Some((o, (x - l) / (r - l).max(1.0)))
    }

    /// Teclado: Tab/Shift+Tab move o foco, Espaço/Enter aciona, setas mudam valor ou seção.
    fn key(&mut self, vk: u16) -> Option<(Act, f32)> {
        let n = self.zones.len();
        if n == 0 {
            return None;
        }
        if vk == VK_TAB.0 {
            let back = unsafe { GetKeyState(VK_SHIFT.0 as i32) } < 0;
            self.focus = Some(match self.focus {
                None if back => n - 1,
                None => 0,
                Some(i) if back => (i + n - 1) % n,
                Some(i) => (i + 1) % n,
            });
            self.redraw();
            return None;
        }
        let i = self.focus.filter(|&i| i < n)?;
        let act = self.zones[i].act;
        let dir = match vk {
            v if v == VK_LEFT.0 || v == VK_UP.0 => -1.0,
            v if v == VK_RIGHT.0 || v == VK_DOWN.0 => 1.0,
            v if v == VK_SPACE.0 || v == VK_RETURN.0 => return Some((act, 0.0)),
            _ => return None,
        };
        match act {
            Act::Slider(o, ..) => Some((act, value(o) + dir * step(o))),
            Act::Page(p) => {
                let p = (p as i32 + dir as i32).clamp(0, PAGES.len() as i32 - 1) as usize;
                self.focus = Some(p);
                Some((Act::Page(p), 0.0))
            }
            _ => None,
        }
    }
}

/// Esquema da barra do topo em `r`: três zonas com os módulos visíveis, na ordem.
fn preview(
    pm: &mut PixmapMut,
    text: &mut impl FnMut(&str, Font, [f32; 4], DWRITE_TEXT_ALIGNMENT, [f32; 4]),
    pal: &Palette,
    [x, y, w, h]: [f32; 4],
    s: f32,
) {
    let tf = Transform::identity();
    let fill = |pm: &mut PixmapMut, [x, y, w, h]: [f32; 4], r: f32, c: [u8; 4]| {
        if let Some(p) = rounded_rect(x, y, w, h, r) {
            pm.fill_path(&p, &paint(c), tiny_skia::FillRule::Winding, tf, None);
        }
    };
    fill(pm, [x, y, w, h], CARD_RADIUS * s, pal.card);
    let zw = w / 3.0;
    let list = config::modules();
    for (zi, zone) in BarZone::ALL.into_iter().enumerate() {
        let zx = x + zi as f32 * zw;
        if zi > 0
            && let Some(line) = Rect::from_xywh(zx, y + 10.0 * s, 1.0, h - 20.0 * s)
        {
            pm.fill_rect(line, &paint(pal.line), tf, None);
        }
        let mods: Vec<&Slot> = list.iter().filter(|m| m.zone == zone && m.on).collect();
        if mods.is_empty() {
            text(&tr(zone.label()), Font::Small, [zx, y, zw, h], DWRITE_TEXT_ALIGNMENT_CENTER, pal.dim);
            continue;
        }
        // Fichas do mesmo tamanho, encostadas no lado da zona (centro: centralizadas).
        let (pad, gap) = (8.0 * s, 4.0 * s);
        let n = mods.len() as f32;
        let cw = ((zw - 2.0 * pad - gap * (n - 1.0)) / n).min(84.0 * s);
        let total = cw * n + gap * (n - 1.0);
        let mut cx = match zone {
            BarZone::Left => zx + pad,
            BarZone::Center => zx + (zw - total) / 2.0,
            BarZone::Right => zx + zw - pad - total,
        };
        for m in mods {
            let r = [cx, y + 9.0 * s, cw, h - 18.0 * s];
            fill(pm, r, 6.0 * s, pal.control);
            text(&tr(m.module.short()), Font::Small, r, DWRITE_TEXT_ALIGNMENT_CENTER, pal.ink);
            cx += cw + gap;
        }
    }
}

/// Tema escuro na barra de título e fundo Mica (Windows 11), conforme o tema do sistema.
fn apply_theme(hwnd: HWND) {
    unsafe {
        let dark = BOOL::from(!crate::light_theme());
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark as *const _ as *const c_void, 4);
        let mica = DWMSBT_MAINWINDOW;
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_SYSTEMBACKDROP_TYPE, &mica as *const _ as *const c_void, 4);
        let round = DWMWCP_ROUND;
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &round as *const _ as *const c_void, 4);
        let all = MARGINS { cxLeftWidth: -1, cxRightWidth: -1, cyTopHeight: -1, cyBottomHeight: -1 };
        let _ = DwmExtendFrameIntoClientArea(hwnd, &all);
    }
}

/// Abre a janela de Configurações; se já está aberta, traz para a frente.
pub fn open() {
    unsafe {
        let open = hwnd();
        if !open.is_invalid() {
            if IsIconic(open).as_bool() {
                let _ = ShowWindow(open, SW_RESTORE);
            }
            let _ = SetForegroundWindow(open);
            return;
        }
        let Ok(module) = GetModuleHandleW(None) else { return };
        let hinst: HINSTANCE = module.into();
        let class = w!("ArcDockWinSettings");
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: hinst,
            lpszClassName: class,
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        // Falha a partir da segunda vez (classe já existe): tudo bem.
        RegisterClassW(&wc);

        // No monitor do mouse (onde está o dock), centrada na área de trabalho.
        let mut pt = POINT::default();
        let _ = GetCursorPos(&mut pt);
        let monitor = MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
        let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(monitor, &mut mi);
        let (mut dpi, mut dy) = (96u32, 96u32);
        let _ = GetDpiForMonitor(monitor, MDT_EFFECTIVE_DPI, &mut dpi, &mut dy);
        let s = dpi as f32 / 96.0;
        let style = WS_POPUP | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX;
        let mut r = RECT { left: 0, top: 0, right: (WIDTH * s).round() as i32, bottom: ((HEIGHT + TITLEBAR + TAB_BAR) * s).round() as i32 };
        let _ = AdjustWindowRectExForDpi(&mut r, style, false, WINDOW_EX_STYLE(0), dpi);
        let (ww, wh) = (r.right - r.left, r.bottom - r.top);
        let work = mi.rcWork;
        let (x, y) = ((work.left + work.right - ww) / 2, (work.top + work.bottom - wh) / 2);
        let title = HSTRING::from("Configurações do PeraDock");
        let Ok(hwnd) = CreateWindowExW(WINDOW_EX_STYLE(0), class, &title, style, x, y, ww, wh, None, None, Some(hinst), None)
        else {
            return;
        };
        let scale = GetDpiForWindow(hwnd) as f32 / 96.0;
        let Ok(text) = Text::new(scale) else {
            let _ = DestroyWindow(hwnd);
            return;
        };
        apply_theme(hwnd);
        let _ = SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        let mut win = Win {
            hwnd,
            scale,
            text,
            buf: None,
            page: 0,
            zones: Vec::new(),
            hot: None,
            pressed: None,
            drag: None,
            focus: None,
            tracking: false,
        };
        win.redraw();
        WIN.with(|w| *w.borrow_mut() = Some(win));
        HWND_OPEN.store(hwnd.0 as isize, Ordering::Relaxed);
        let _ = ShowWindow(hwnd, SW_SHOW);
        let _ = SetForegroundWindow(hwnd);
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    unsafe {
        match msg {
            WM_NCCALCSIZE => {
                // A área cliente inteira pertence a esta janela. O DWM não desenha a legenda padrão.
                if wp.0 != 0 && lp.0 != 0 && IsZoomed(hwnd).as_bool() {
                    let params = &mut *(lp.0 as *mut NCCALCSIZE_PARAMS);
                    let mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
                    let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
                    if GetMonitorInfoW(mon, &mut mi).as_bool() {
                        params.rgrc[0] = mi.rcWork;
                    }
                }
                LRESULT(0)
            }
            WM_NCHITTEST => {
                let mut point = POINT { x: (lp.0 & 0xffff) as i16 as i32, y: ((lp.0 >> 16) & 0xffff) as i16 as i32 };
                let _ = ScreenToClient(hwnd, &mut point);
                let caption = with_win(|w| {
                    let x = point.x as f32;
                    let y = point.y as f32;
                    y >= 0.0 && y < TITLEBAR * w.scale && !w.zones.iter().any(|z| {
                        matches!(z.act, Act::Window(_)) && x >= z.r[0] && x < z.r[0] + z.r[2] && y >= z.r[1] && y < z.r[1] + z.r[3]
                    })
                }).unwrap_or(false);
                LRESULT((if caption { HTCAPTION } else { HTCLIENT }) as isize)
            }
            WM_NCPAINT => LRESULT(0),
            WM_UPDATE_DONE => {
                update_done(hwnd, wp.0 as u32, lp.0 != 0);
                LRESULT(0)
            }
            WM_SIZE => {
                with_win(|w| w.redraw());
                LRESULT(0)
            }
            WM_PAINT => {
                let mut ps = PAINTSTRUCT::default();
                let hdc = BeginPaint(hwnd, &mut ps);
                with_win(|w| {
                    if let Some(b) = &w.buf {
                        let _ = BitBlt(hdc, 0, 0, b.w, b.h, Some(b.memdc), 0, 0, SRCCOPY);
                    }
                });
                let _ = EndPaint(hwnd, &ps);
                LRESULT(0)
            }
            WM_ERASEBKGND => LRESULT(1),
            WM_MOUSEMOVE => {
                let (x, slide_to) = (lp, with_win(|w| w.drag_value(w.hit(lp).0)).flatten());
                if let Some((o, v)) = slide_to {
                    slide(o, v, false);
                }
                with_win(|w| {
                    if !w.tracking {
                        w.tracking = true;
                        let mut tme = TRACKMOUSEEVENT {
                            cbSize: size_of::<TRACKMOUSEEVENT>() as u32,
                            dwFlags: TME_LEAVE,
                            hwndTrack: hwnd,
                            dwHoverTime: 0,
                        };
                        let _ = TrackMouseEvent(&mut tme);
                    }
                    let hot = w.hit(x).1;
                    if hot != w.hot || slide_to.is_some() {
                        w.hot = hot;
                        w.redraw();
                    }
                });
                LRESULT(0)
            }
            WM_MOUSELEAVE => {
                with_win(|w| {
                    w.tracking = false;
                    if w.hot.take().is_some() {
                        w.redraw();
                    }
                });
                LRESULT(0)
            }
            WM_LBUTTONDOWN => {
                let slide_to = with_win(|w| {
                    w.focus = None;
                    let (x, i) = w.hit(lp);
                    SetCapture(hwnd);
                    match i.map(|i| (i, w.zones[i].act)) {
                        Some((_, Act::Slider(o, l, r))) => {
                            w.drag = Some((o, l, r));
                            w.drag_value(x)
                        }
                        Some((i, _)) => {
                            w.pressed = Some(i);
                            None
                        }
                        None => None,
                    }
                })
                .flatten();
                if let Some((o, v)) = slide_to {
                    slide(o, v, false);
                }
                with_win(|w| w.redraw());
                LRESULT(0)
            }
            WM_LBUTTONUP => {
                let _ = ReleaseCapture();
                let done = with_win(|w| {
                    if let Some((o, _, _)) = w.drag.take() {
                        return Some((Act::Slider(o, 0.0, 0.0), true));
                    }
                    let i = w.pressed.take()?;
                    (w.hit(lp).1 == Some(i)).then(|| (w.zones[i].act, false))
                })
                .flatten();
                match done {
                    // Fim do arrasto: recarrega os ícones no tamanho novo.
                    Some((Act::Slider(o, ..), true)) => slide(o, value(o), true),
                    Some((act, _)) => run(act),
                    None => {}
                }
                with_win(|w| w.redraw());
                LRESULT(0)
            }
            WM_KEYDOWN => {
                let act = match with_win(|w| w.key(wp.0 as u16)).flatten() {
                    Some((Act::Slider(o, ..), v)) => {
                        slide(o, v, true);
                        None
                    }
                    Some((act, _)) => {
                        run(act);
                        Some(act)
                    }
                    None => return LRESULT(0),
                };
                with_win(|w| {
                    w.redraw();
                    // A lista pode ter mudado (módulo subiu/desceu): o foco segue a mesma ação.
                    if let Some(i) = act.and_then(|a| w.zones.iter().position(|z| z.act == a))
                        && w.focus != Some(i)
                    {
                        w.focus = Some(i);
                        w.redraw();
                    }
                });
                LRESULT(0)
            }
            WM_DPICHANGED => {
                // Outro monitor (ou escala mudou): fontes na escala nova e o tamanho sugerido.
                let scale = (wp.0 & 0xffff) as f32 / 96.0;
                if let Ok(text) = Text::new(scale) {
                    with_win(|w| {
                        w.scale = scale;
                        w.text = text;
                    });
                }
                let r = &*(lp.0 as *const RECT);
                let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
                with_win(|w| w.redraw());
                LRESULT(0)
            }
            WM_SETTINGCHANGE => {
                // Pode ser a troca de tema claro/escuro.
                apply_theme(hwnd);
                with_win(|w| w.redraw());
                DefWindowProcW(hwnd, msg, wp, lp)
            }
            WM_DESTROY => {
                HWND_OPEN.store(0, Ordering::Relaxed);
                let old = WIN.with(|w| w.try_borrow_mut().ok().and_then(|mut g| g.take()));
                drop(old);
                LRESULT(0)
            }
            _ => DefWindowProcW(hwnd, msg, wp, lp),
        }
    }
}
