//! Apps do dock: fixados (configuração) e abertos, ícones e ações de clique.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use tiny_skia::Pixmap;
use windows::Win32::Foundation::{CloseHandle, HWND, LPARAM, SIZE, WPARAM};
use windows::Win32::Graphics::Dwm::{DWMWA_CLOAKED, DwmGetWindowAttribute};
use windows::Win32::Graphics::Gdi::{
    BI_RGB, BITMAP, BITMAPINFO, BITMAPINFOHEADER, DIB_RGB_COLORS, DeleteObject, GetDC, GetDIBits,
    GdiFlush, GetObjectW, HBITMAP, HGDIOBJ, ReleaseDC,
};
use windows::Win32::Storage::EnhancedStorage::PKEY_AppUserModel_ID;
use windows::Win32::System::Diagnostics::ToolHelp::{
    CreateToolhelp32Snapshot, PROCESSENTRY32W, Process32FirstW, Process32NextW, TH32CS_SNAPPROCESS,
};
use windows::Win32::System::Threading::{
    OpenProcess, PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION, QueryFullProcessImageNameW,
};
use windows::Win32::UI::Shell::PropertiesSystem::{IPropertyStore, SHGetPropertyStoreForWindow};
use windows::Win32::UI::Shell::{
    IShellItemImageFactory, SHCreateItemFromParsingName, SIIGBF_ICONONLY, ShellExecuteW,
};
use windows::Win32::UI::WindowsAndMessaging::{
    DI_NORMAL, DestroyIcon, DrawIconEx, EnumWindows, GW_OWNER, HICON, PrivateExtractIconsW, GWL_EXSTYLE, GetClassNameW, GetForegroundWindow, GetWindow,
    GetWindowLongW, GetWindowTextLengthW, GetWindowTextW, GetWindowThreadProcessId, IsIconic, IsWindowVisible,
    PostMessageW, SC_MINIMIZE, SW_MINIMIZE, SW_SHOWNORMAL, SetForegroundWindow, ShowWindow,
    SwitchToThisWindow, WM_SYSCOMMAND, WS_EX_TOOLWINDOW,
};
use windows::core::{BOOL, HSTRING, PWSTR, w};
use windows::core::{Interface, PCSTR};
use windows::Win32::Foundation::{LRESULT, POINT};
use windows::Win32::UI::Shell::{
    BHID_SFUIObject, CMF_NORMAL, CMINVOKECOMMANDINFO, IContextMenu, IContextMenu3, IShellItem,
};
use windows::Win32::UI::WindowsAndMessaging::{
    CreatePopupMenu, DestroyMenu, TRACK_POPUP_MENU_FLAGS, TrackPopupMenu, WM_DRAWITEM, WM_INITMENUPOPUP,
    WM_MEASUREITEM, WM_MENUCHAR,
};

pub const APPS_FOLDER: &str = "shell:AppsFolder\\";

pub struct App {
    /// Caminho do .exe ou `shell:AppsFolder\<id>` (apps da Store).
    pub source: String,
    /// Identifica o app ao casar com as janelas abertas.
    pub key: String,
    pub pinned: bool,
    pub icon: Option<Pixmap>,
    /// Janelas abertas do app, na ordem em que apareceram.
    pub windows: Vec<HWND>,
}

const DEFAULT_CONFIG: &str = "\
# PeraDock - apps fixados no dock
# Um caminho de .exe por linha (ou shell:AppsFolder\\<id> para apps da Store).
# Linhas começando com # são ignoradas.
C:\\Windows\\explorer.exe
C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe
C:\\Windows\\System32\\notepad.exe
";

pub fn config_path() -> PathBuf {
    let base = std::env::var_os("APPDATA").map(PathBuf::from).unwrap_or_default();
    base.join("ArcDockWin").join("pinned.txt")
}

pub fn load_pinned(icon_size: i32) -> Vec<App> {
    let cfg = config_path();
    if !cfg.exists() {
        if let Some(dir) = cfg.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        let _ = std::fs::write(&cfg, DEFAULT_CONFIG);
    }
    let mut text = std::fs::read_to_string(&cfg).unwrap_or_else(|_| DEFAULT_CONFIG.to_string());
    if !crate::config::whatsapp_added() {
        let already_pinned = text.lines().any(|line| is_whatsapp(line.trim()));
        if already_pinned {
            crate::config::mark_whatsapp_added();
        } else if let Some(source) = registered_whatsapp() {
            let updated = format!("{}\n{source}\n", text.trim_end());
            if std::fs::write(&cfg, &updated).is_ok() { crate::config::mark_whatsapp_added(); }
            text = updated;
        }
    }

    let start = App {
        source: START.to_string(),
        key: START.to_string(),
        pinned: true,
        icon: load_icon(START, icon_size),
        windows: Vec::new(),
    };
    // O botão Iniciar fica na ponta direita, depois dos fixados e dos abertos.
    let apps: Vec<App> = text
        .lines()
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .filter(|l| *l == SETTINGS || l.starts_with(APPS_FOLDER) || Path::new(l).exists())
        .map(|source| App {
            key: source_key(source),
            icon: load_icon(source, icon_size),
            source: source.to_string(),
            pinned: true,
            windows: Vec::new(),
        })
        .chain(std::iter::once(start))
        .collect();
    apps
}

/// Item especial do botão Iniciar.
pub const START: &str = "::start";
pub(crate) const SETTINGS: &str = "::peradock-settings";
const WHATSAPP: &str = r"shell:AppsFolder\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App";

/// Pera prateada do PeraDock. O arquivo de 128 × 128 já está em RGBA pré-multiplicado.
pub(crate) fn start_icon(size: u32) -> Option<Pixmap> {
    use tiny_skia::{FilterQuality, IntSize, PixmapPaint, Transform};

    let source = Pixmap::from_vec(include_bytes!("pera.rgba").to_vec(), IntSize::from_wh(128, 128)?)?;
    let mut icon = Pixmap::new(size, size)?;
    let scale = size as f32 / 128.0;
    let paint = PixmapPaint { quality: FilterQuality::Bicubic, ..Default::default() };
    icon.draw_pixmap(0, 0, source.as_ref(), &paint, Transform::from_scale(scale, scale), None);
    Some(icon)
}

pub(crate) fn source_key(source: &str) -> String {
    if is_whatsapp(source) { return "peradock:whatsapp".to_string(); }
    match source.strip_prefix(APPS_FOLDER) {
        Some(id) => format!("aumid:{}", id.to_lowercase()),
        None => exe_key(source),
    }
}

fn exe_key(path: &str) -> String {
    Path::new(path)
        .file_name()
        .map(|n| n.to_string_lossy().to_lowercase())
        .unwrap_or_default()
}

/// Ícones trocados por fora (`nome.exe=C:\caminho\icone.ico`), escrito pelo IconesTahoe.
pub fn icons_path() -> PathBuf {
    config_path().with_file_name("icons.txt")
}

fn icon_override(source: &str) -> Option<String> {
    let key = if source == START { "start".to_string() } else { exe_key(source) };
    std::fs::read_to_string(icons_path())
        .ok()?
        .lines()
        .filter_map(|l| l.split_once('='))
        .find(|(k, _)| k.trim().eq_ignore_ascii_case(&key))
        .map(|(_, v)| v.trim().to_string())
        .filter(|p| Path::new(p).exists())
}

/// Recarrega os ícones de todos os apps (o arquivo de ícones trocados mudou).
pub fn reload_icons(apps: &mut [App], size: i32) {
    for app in apps.iter_mut() {
        app.icon = load_icon(&app.source, size);
    }
}

/// Ícone em alta resolução, como pixmap RGBA pré-multiplicado.
pub fn load_icon(source: &str, size: i32) -> Option<Pixmap> {
    if source == START || source == SETTINGS { return start_icon(size as u32); }
    if let Some(icon) = icon_override(source).and_then(|path| file_icon(&path, size)) {
        return Some(icon);
    }
    if is_whatsapp(source) { return whatsapp_icon(size as u32); }
    file_icon(source, size)
}

fn file_icon(source: &str, size: i32) -> Option<Pixmap> {
    let extension = Path::new(source).extension().and_then(|ext| ext.to_str());
    let icon = match extension.map(str::to_ascii_lowercase).as_deref() {
        Some("lnk") => shortcut_icon(source, size),
        Some("url") => internet_shortcut_icon(source, size),
        Some("exe" | "ico" | "dll") => resource_icon(Path::new(source), 0, size),
        _ => None,
    };
    icon.or_else(|| shell_icon(source, size))
}
pub(crate) fn display_name(source: &str) -> Option<String> {
    use windows::Win32::System::Com::CoTaskMemFree;
    use windows::Win32::UI::Shell::SIGDN_NORMALDISPLAY;
    unsafe {
        let item: IShellItem = SHCreateItemFromParsingName(&HSTRING::from(source),None).ok()?;
        let display=item.GetDisplayName(SIGDN_NORMALDISPLAY).ok()?;
        let result=display.to_string().ok();
        CoTaskMemFree(Some(display.0.cast()));
        result.filter(|s| !s.is_empty())
    }
}

fn shortcut_icon(source: &str, size: i32) -> Option<Pixmap> {
    use windows::Win32::System::Com::{CLSCTX_INPROC_SERVER, CoCreateInstance, IPersistFile, STGM_READ};
    use windows::Win32::UI::Shell::{IShellLinkW, ShellLink};

    unsafe {
        let link: IShellLinkW = CoCreateInstance(&ShellLink, None, CLSCTX_INPROC_SERVER).ok()?;
        link.cast::<IPersistFile>().ok()?.Load(&HSTRING::from(source), STGM_READ).ok()?;

        let mut icon = [0u16; 1024];
        let mut index = 0;
        if link.GetIconLocation(&mut icon, &mut index).is_ok() {
            let raw = String::from_utf16_lossy(&icon[..icon.iter().position(|&c| c == 0)?]);
            if !raw.is_empty() {
                return resolve_icon_path(source, &raw).and_then(|path| resource_icon(&path, index, size));
            }
        }

        None
    }
}

fn internet_shortcut_icon(source: &str, size: i32) -> Option<Pixmap> {
    let bytes = std::fs::read(source).ok()?;
    let contents = if let Some(utf16) = bytes.strip_prefix(&[0xFF, 0xFE]) {
        String::from_utf16_lossy(&utf16.chunks_exact(2)
            .map(|pair| u16::from_le_bytes([pair[0], pair[1]])).collect::<Vec<_>>())
    } else {
        String::from_utf8_lossy(&bytes).trim_start_matches('\u{feff}').to_owned()
    };
    let mut lines = contents.lines().map(str::trim)
        .skip_while(|line| !line.eq_ignore_ascii_case("[InternetShortcut]"))
        .skip(1).take_while(|line| !line.starts_with('['));
    let mut file = None;
    let mut index = 0;
    for (key, value) in lines.by_ref().filter_map(|line| line.split_once('=')) {
        if key.trim().eq_ignore_ascii_case("IconFile") { file = Some(value.trim()); }
        if key.trim().eq_ignore_ascii_case("IconIndex") { index = value.trim().parse().unwrap_or(0); }
    }
    let path = resolve_icon_path(source, file?)?;
    resource_icon(&path, index, size)
}

fn resolve_icon_path(source: &str, resource: &str) -> Option<PathBuf> {
    let mut expanded = String::new();
    for (i, part) in resource.trim().trim_matches('"').split('%').enumerate() {
        if i % 2 == 0 { expanded.push_str(part); }
        else { expanded.push_str(&std::env::var(part).ok()?); }
    }
    let path = PathBuf::from(expanded);
    if path.is_absolute() { Some(path) } else { Some(Path::new(source).parent()?.join(path)) }
}

fn resource_icon(path: &Path, index: i32, size: i32) -> Option<Pixmap> {
    use std::os::windows::ffi::OsStrExt;

    if !path.is_file() { return None; }
    let mut name = [0u16; 260];
    let utf16: Vec<_> = path.as_os_str().encode_wide().collect();
    let output = name.get_mut(..utf16.len())?;
    if output.len() == 260 { return None; }
    output.copy_from_slice(&utf16);

    unsafe {
        let mut icons = [HICON::default()];
        if PrivateExtractIconsW(&name, index, size, size, Some(&mut icons), None, 0) != 1
            || icons[0].is_invalid()
        {
            return None;
        }
        let result = draw_native_icon(icons[0], size).and_then(trim_transparent);
        let _ = DestroyIcon(icons[0]);
        result
    }
}

/// Compõe o HICON sobre duas cores para recuperar o alfa, inclusive nos ícones
/// antigos em que a transparência existe só na máscara do Windows.
fn draw_native_icon(icon: HICON, size: i32) -> Option<Pixmap> {
    let dark = crate::panel::Buffer::new(size, size)?;
    let light = crate::panel::Buffer::new(size, size)?;
    let mut pixels = Pixmap::new(size as u32, size as u32)?;
    let length = pixels.data().len();

    unsafe {
        std::slice::from_raw_parts_mut(dark.bits, length).fill(0);
        std::slice::from_raw_parts_mut(light.bits, length).fill(255);
        DrawIconEx(dark.memdc, 0, 0, icon, size, size, 0, None, DI_NORMAL).ok()?;
        DrawIconEx(light.memdc, 0, 0, icon, size, size, 0, None, DI_NORMAL).ok()?;
        let _ = GdiFlush();
        let black = std::slice::from_raw_parts(dark.bits, length);
        let white = std::slice::from_raw_parts(light.bits, length);
        for ((out, black), white) in pixels.data_mut().chunks_exact_mut(4)
            .zip(black.chunks_exact(4)).zip(white.chunks_exact(4))
        {
            let uncovered: u16 = (0..3).map(|i| u16::from(white[i].saturating_sub(black[i]))).sum();
            let alpha = 255 - ((uncovered + 1) / 3) as u8;
            out.copy_from_slice(&[black[2].min(alpha), black[1].min(alpha), black[0].min(alpha), alpha]);
        }
    }
    Some(pixels)
}
fn shell_icon(source: &str, size: i32) -> Option<Pixmap> {
    unsafe {
        let factory: IShellItemImageFactory =
            SHCreateItemFromParsingName(&HSTRING::from(source), None).ok()?;
        let hbmp = factory
            .GetImage(SIZE { cx: size, cy: size }, SIIGBF_ICONONLY)
            .ok()?;
        let pixmap = hbitmap_to_pixmap(hbmp);
        let _ = DeleteObject(HGDIOBJ(hbmp.0));
        pixmap.and_then(trim_transparent)
    }
}

fn registered_whatsapp() -> Option<String> {
    static SOURCE: std::sync::OnceLock<Option<String>> = std::sync::OnceLock::new();
    SOURCE.get_or_init(|| {
        if unsafe { SHCreateItemFromParsingName::<_, _, IShellItem>(&HSTRING::from(WHATSAPP), None) }.is_ok() {
            Some(WHATSAPP.to_string())
        } else {
            crate::launcher::whatsapp_source()
        }
    }).clone()
}

pub(crate) fn is_whatsapp(source: &str) -> bool {
    let source = source.to_ascii_lowercase();
    let known_pwa = source.starts_with("shell:appsfolder\\")
        && registered_whatsapp().is_some_and(|app| app.eq_ignore_ascii_case(&source));
    known_pwa || (source.contains("5319275a.whatsappdesktop") && !source.contains("desktopbeta"))
        || matches!(exe_key(&source).as_str(), "whatsapp.exe" | "whatsapp.root.exe" | "whatsappdesktop.exe")
}

pub(crate) fn whatsapp_icon(size: u32) -> Option<Pixmap> {
    use tiny_skia::{FillRule, Paint, PathBuilder, Stroke, Transform};
    let mut icon = Pixmap::new(size, size)?;
    let scale = size as f32 / 32.0;
    let transform = Transform::from_scale(scale, scale);
    let mut green = Paint::default();
    green.set_color_rgba8(24, 174, 98, 255);
    green.anti_alias = true;
    icon.fill_path(&PathBuilder::from_circle(16.0, 16.0, 15.5)?, &green, FillRule::Winding, transform, None);
    let mut white = green;
    white.set_color_rgba8(255, 255, 255, 255);
    let mut bubble = PathBuilder::new();
    bubble.move_to(8.0, 22.0); bubble.line_to(6.5, 25.5); bubble.line_to(11.0, 24.3);
    bubble.cubic_to(21.0, 29.0, 28.5, 18.0, 23.9, 10.0);
    bubble.cubic_to(18.3, 1.0, 3.0, 8.0, 7.2, 19.7); bubble.line_to(8.0, 22.0);
    icon.stroke_path(&bubble.finish()?, &white, &Stroke { width: 1.9, ..Default::default() }, transform, None);
    let mut phone = PathBuilder::new();
    phone.move_to(12.1, 10.6); phone.cubic_to(8.5, 11.1, 11.0, 17.4, 15.7, 20.3);
    phone.cubic_to(19.4, 22.6, 22.0, 20.7, 21.3, 18.9); phone.line_to(18.5, 17.4);
    phone.line_to(16.8, 18.3); phone.quad_to(13.8, 16.4, 13.3, 14.2);
    phone.line_to(14.0, 13.0); phone.line_to(12.9, 10.6); phone.close();
    icon.fill_path(&phone.finish()?, &white, FillRule::Winding, transform, None);
    Some(icon)
}

/// Corta as margens transparentes do ícone, para todos ocuparem a caixa por igual.
fn trim_transparent(pm: Pixmap) -> Option<Pixmap> {
    let (w, h) = (pm.width(), pm.height());
    let alpha = |x: u32, y: u32| pm.data()[((y * w + x) * 4 + 3) as usize];
    let (mut l, mut t, mut r, mut b) = (w, h, 0, 0);
    for y in 0..h {
        for x in 0..w {
            if alpha(x, y) >= 32 {
                l = l.min(x);
                t = t.min(y);
                r = r.max(x + 1);
                b = b.max(y + 1);
            }
        }
    }
    if l >= r || t >= b {
        return pm.data().chunks_exact(4).any(|pixel| pixel[3] != 0).then_some(pm);
    }
    // Uma pequena margem conserva o contorno suavizado sem enquadrar halos fracos.
    let pad = (w.max(h) / 48).max(1);
    let rect = tiny_skia::IntRect::from_ltrb(
        l.saturating_sub(pad) as i32, t.saturating_sub(pad) as i32,
        (r + pad).min(w) as i32, (b + pad).min(h) as i32,
    )?;
    pm.clone_rect(rect)
}

unsafe fn hbitmap_to_pixmap(hbmp: HBITMAP) -> Option<Pixmap> {
    unsafe {
        let mut bm = BITMAP::default();
        if GetObjectW(
            HGDIOBJ(hbmp.0),
            size_of::<BITMAP>() as i32,
            Some(&mut bm as *mut _ as *mut _),
        ) == 0
        {
            return None;
        }
        let (w, h) = (bm.bmWidth, bm.bmHeight.abs());
        let mut bmi = BITMAPINFO {
            bmiHeader: BITMAPINFOHEADER {
                biSize: size_of::<BITMAPINFOHEADER>() as u32,
                biWidth: w,
                biHeight: -h, // de cima para baixo
                biPlanes: 1,
                biBitCount: 32,
                biCompression: BI_RGB.0,
                ..Default::default()
            },
            ..Default::default()
        };
        let mut buf = vec![0u8; (w * h * 4) as usize];
        let hdc = GetDC(None);
        let lines = GetDIBits(
            hdc,
            hbmp,
            0,
            h as u32,
            Some(buf.as_mut_ptr() as *mut _),
            &mut bmi,
            DIB_RGB_COLORS,
        );
        ReleaseDC(None, hdc);
        if lines == 0 {
            return None;
        }

        // BGRA -> RGBA. Se algum canal passar do alfa, a imagem não está pré-multiplicada.
        let straight = buf
            .chunks_exact(4)
            .any(|p| p[0] > p[3] || p[1] > p[3] || p[2] > p[3]);
        for p in buf.chunks_exact_mut(4) {
            p.swap(0, 2);
            if straight {
                let a = p[3] as u16;
                for c in &mut p[..3] {
                    *c = ((*c as u16 * a + 127) / 255) as u8;
                }
            }
        }
        Pixmap::from_vec(buf, tiny_skia::IntSize::from_wh(w as u32, h as u32)?)
    }
}

/// Atualiza as janelas de cada app e a lista de apps abertos não fixados.
/// Retorna true se algo mudou.
pub fn refresh(apps: &mut Vec<App>, icon_size: i32) -> bool {
    refresh_windows(apps, Some(icon_size))
}

pub fn refresh_pinned(apps: &mut Vec<App>) -> bool {
    refresh_windows(apps, None)
}

fn refresh_windows(apps: &mut Vec<App>, icon_size: Option<i32>) -> bool {
    let mut hwnds: Vec<HWND> = Vec::new();
    unsafe {
        let _ = EnumWindows(Some(enum_cb), LPARAM(&mut hwnds as *mut _ as isize));
    }

    let mut procs: HashMap<u32, String> = HashMap::new();
    let mut order: Vec<String> = Vec::new();
    let mut groups: HashMap<String, (String, Vec<HWND>)> = HashMap::new();
    for hwnd in hwnds {
        let Some((key, source)) = window_app(hwnd, &mut procs) else { continue };
        groups
            .entry(key.clone())
            .or_insert_with(|| {
                order.push(key);
                (source, Vec::new())
            })
            .1
            .push(hwnd);
    }

    let mut changed = false;
    for app in apps.iter_mut() {
        let found = groups.remove(&app.key).map(|g| g.1).unwrap_or_default();
        // Ordem estável: as que já estavam ficam no lugar, as novas vão para o fim.
        let mut new: Vec<HWND> = app.windows.iter().copied().filter(|h| found.contains(h)).collect();
        new.extend(found.into_iter().filter(|h| !app.windows.contains(h)));
        if new != app.windows {
            changed = true;
            app.windows = new;
        }
    }

    let Some(icon_size) = icon_size else { return changed; };
    let before = apps.len();
    apps.retain(|a| a.pinned || !a.windows.is_empty());
    changed |= apps.len() != before;

    for key in order {
        if let Some((source, windows)) = groups.remove(&key) {
            let icon = load_icon(&source, icon_size);
            // Antes do botão Iniciar, que é sempre o último.
            let at = apps.iter().position(|a| a.source == START).unwrap_or(apps.len());
            apps.insert(at, App {
                icon,
                source,
                key,
                pinned: false,
                windows,
            });
            changed = true;
        }
    }
    changed
}

/// (key, source) do app dono da janela.
fn window_app(hwnd: HWND, procs: &mut HashMap<u32, String>) -> Option<(String, String)> {
    if hwnd == crate::settings::hwnd() { return Some((SETTINGS.to_string(), SETTINGS.to_string())); }
    let mut pid = 0u32;
    unsafe { GetWindowThreadProcessId(hwnd, Some(&mut pid)) };
    let path = procs.entry(pid).or_insert_with(|| host_path(pid)).clone();
    let key = exe_key(&path);
    if key.is_empty() { return None; }
    if matches!(key.as_str(), "applicationframehost.exe" | "msedgewebview2.exe" | "msedge.exe" | "chrome.exe" | "brave.exe")
       && let Some(id) = window_aumid(hwnd) {
        let source = format!("{APPS_FOLDER}{id}");
        if is_whatsapp(&source) { return Some((source_key(&source), source)); }
    }
    if matches!(key.as_str(), "msedgewebview2.exe" | "applicationframehost.exe")
        && {
            let title = menu_title(hwnd);
            title.eq_ignore_ascii_case("WhatsApp") || title.starts_with("WhatsApp (")
        }
    {
        let source = registered_whatsapp().unwrap_or_else(|| WHATSAPP.to_string());
        return Some((source_key(&source), source));
    }
    if key == "applicationframehost.exe" {
        // Apps da Store rodam dentro do ApplicationFrameHost; o app real vem do AppUserModelID.
        let id = window_aumid(hwnd)?;
        let source = format!("{APPS_FOLDER}{id}");
        return Some((source_key(&source), source));
    }
    if is_whatsapp(&path) {
        let source = if path.to_ascii_lowercase().contains(r"\windowsapps\") { WHATSAPP.to_string() } else { path };
        return Some((source_key(&source), source));
    }
    Some((key, path))
}

fn window_aumid(hwnd: HWND) -> Option<String> {
    unsafe {
        let store: IPropertyStore = SHGetPropertyStoreForWindow(hwnd).ok()?;
        let value = store.GetValue(&PKEY_AppUserModel_ID).ok()?;
        let id = value.to_string();
        (!id.is_empty()).then_some(id)
    }
}

unsafe extern "system" fn enum_cb(hwnd: HWND, lparam: LPARAM) -> BOOL {
    unsafe {
        if is_app_window(hwnd) {
            (*(lparam.0 as *mut Vec<HWND>)).push(hwnd);
        }
    }
    BOOL(1)
}

/// Janelas que apareceriam na barra de tarefas.
unsafe fn is_app_window(hwnd: HWND) -> bool {
    unsafe {
        if !IsWindowVisible(hwnd).as_bool() || GetWindowTextLengthW(hwnd) == 0 {
            return false;
        }
        if GetWindow(hwnd, GW_OWNER).is_ok_and(|o| !o.is_invalid()) {
            return false;
        }
        // As janelas do próprio dock (topbar, painéis...) não são apps; a de Configurações é.
        let mut pid = 0u32;
        GetWindowThreadProcessId(hwnd, Some(&mut pid));
        if pid == windows::Win32::System::Threading::GetCurrentProcessId() && hwnd != crate::settings::hwnd() {
            return false;
        }
        if GetWindowLongW(hwnd, GWL_EXSTYLE) as u32 & WS_EX_TOOLWINDOW.0 != 0 {
            return false;
        }
        let mut cloaked = 0u32;
        let _ = DwmGetWindowAttribute(
            hwnd,
            DWMWA_CLOAKED,
            &mut cloaked as *mut _ as *mut _,
            size_of::<u32>() as u32,
        );
        if cloaked != 0 {
            return false;
        }
        let mut class = [0u16; 64];
        let len = GetClassNameW(hwnd, &mut class) as usize;
        let class = String::from_utf16_lossy(&class[..len]);
        !matches!(class.as_str(), "Progman" | "WorkerW" | "Shell_TrayWnd")
    }
}

/// Caminho do .exe dono do processo. Janelas do WebView2 (msedgewebview2.exe) ficam com o app
/// que hospeda o WebView2 (ex.: WhatsApp.Root.exe), para o dock mostrar o ícone certo.
fn host_path(pid: u32) -> String {
    let path = process_path(pid);
    if exe_key(&path) != "msedgewebview2.exe" {
        return path;
    }
    let parents = parent_pids();
    let mut cur = pid;
    // Sobe a árvore: renderizador -> navegador do WebView2 -> app.
    for _ in 0..4 {
        let Some(&parent) = parents.get(&cur) else { break };
        let p = process_path(parent);
        if p.is_empty() {
            break;
        }
        if exe_key(&p) != "msedgewebview2.exe" {
            return p;
        }
        cur = parent;
    }
    path
}

/// pid -> pid do pai, de todos os processos.
fn parent_pids() -> HashMap<u32, u32> {
    let mut map = HashMap::new();
    unsafe {
        let Ok(snap) = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) else { return map };
        let mut e = PROCESSENTRY32W { dwSize: size_of::<PROCESSENTRY32W>() as u32, ..Default::default() };
        let mut ok = Process32FirstW(snap, &mut e).is_ok();
        while ok {
            map.insert(e.th32ProcessID, e.th32ParentProcessID);
            ok = Process32NextW(snap, &mut e).is_ok();
        }
        let _ = CloseHandle(snap);
    }
    map
}

fn process_path(pid: u32) -> String {
    unsafe {
        let Ok(handle) = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid) else {
            return String::new();
        };
        let mut buf = [0u16; 1024];
        let mut len = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(buf.as_mut_ptr()),
            &mut len,
        )
        .is_ok();
        let _ = CloseHandle(handle);
        if ok { String::from_utf16_lossy(&buf[..len as usize]) } else { String::new() }
    }
}

/// `shell:AppsFolder\<família>!<id>` de um .exe dentro de `WindowsApps` (app da Store), lido do
/// AppxManifest.xml do pacote. Abrir o .exe direto não funciona para esses apps: com o app
/// fechado na bandeja (ex.: WhatsApp), o clique no dock não fazia nada.
fn store_app_id(path: &str) -> Option<String> {
    const DIR: &str = "\\windowsapps\\";
    let i = path.to_lowercase().find(DIR)? + DIR.len();
    let (folder, exe) = path[i..].split_once('\\')?;
    // Pasta do pacote: <Nome>_<Versão>_<Arquitetura>_<Recurso>_<IdDoEditor>.
    let parts: Vec<&str> = folder.split('_').collect();
    let [name, _, _, _, publisher] = parts[..] else { return None };
    let manifest = std::fs::read_to_string(Path::new(&path[..i]).join(folder).join("AppxManifest.xml")).ok()?;
    manifest.split("<Application ").skip(1).find_map(|tag| {
        let tag = &tag[..tag.find('>')?];
        let executable = xml_attr(tag, "Executable")?.replace('/', "\\");
        executable
            .eq_ignore_ascii_case(exe)
            .then(|| xml_attr(tag, "Id").map(|id| format!("{APPS_FOLDER}{name}_{publisher}!{id}")))
            .flatten()
    })
}

/// Valor do atributo `name="..."` dentro de uma tag XML.
fn xml_attr<'a>(tag: &'a str, name: &str) -> Option<&'a str> {
    let key = format!(" {name}=\"");
    let start = format!(" {tag}").find(&key)? + key.len() - 1;
    let len = tag[start..].find('"')?;
    Some(&tag[start..start + len])
}

/// Clique no ícone: abre o app, alterna entre as janelas dele ou minimiza a única em foco.
pub fn activate(source: &str, windows: &[HWND]) {
    if source == START {
        crate::launcher::toggle();
        return;
    }
    if source == SETTINGS && windows.is_empty() { crate::settings::open(); return; }
    unsafe {
        if windows.is_empty() {
            // App da Store fixado pelo .exe: abre pelo AppUserModelID, como a barra do Windows.
            let target = store_app_id(source).unwrap_or_else(|| source.to_string());
            ShellExecuteW(None, w!("open"), &HSTRING::from(target), None, None, SW_SHOWNORMAL);
            return;
        }
        let fg = GetForegroundWindow();
        // Minimizada pode continuar "em primeiro plano" (sem outra janela para ativar, o
        // Windows deixa o foco nela): não conta como em foco, senão minimizaria de novo.
        let focused = if IsIconic(fg).as_bool() { None } else { windows.iter().position(|&h| h == fg) };
        match focused {
            Some(_) if windows.len() == 1 => {
                crate::minimize::capture(fg); // foto antes de sumir (animação até o ícone)
                let _ = ShowWindow(fg, SW_MINIMIZE);
                // App rodando como administrador: o UIPI nega o ShowWindow, mas deixa passar
                // o WM_SYSCOMMAND, e a própria janela se minimiza.
                if !IsIconic(fg).as_bool() {
                    let _ = PostMessageW(Some(fg), WM_SYSCOMMAND, WPARAM(SC_MINIMIZE as usize), LPARAM(0));
                }
            }
            // Várias janelas: a próxima na ordem estável, em ciclo.
            Some(i) => focus_window(windows[(i + 1) % windows.len()]),
            // Nenhuma em foco: a mais recente não minimizada, ou a primeira se todas estiverem.
            None => {
                let z = z_order(windows);
                let top = z.iter().copied().find(|&h| !IsIconic(h).as_bool());
                focus_window(top.or(z.first().copied()).unwrap_or(windows[0]));
            }
        }
    }
}

/// Scroll through one app's open windows, restoring a minimized target when needed.
pub fn cycle_window(windows: &[HWND], forward: bool) {
    if windows.len() < 2 {
        return;
    }
    unsafe {
        let fg = GetForegroundWindow();
        let current = if let Some(i) = windows.iter().position(|&h| h == fg) {
            Some(i)
        } else {
            let order = z_order(windows);
            order
                .iter()
                .copied()
                .find(|&h| !IsIconic(h).as_bool())
                .or_else(|| order.first().copied())
                .and_then(|h| windows.iter().position(|&w| w == h))
        };
        let Some(i) = current else { return };
        let next = if forward { (i + 1) % windows.len() } else { (i + windows.len() - 1) % windows.len() };
        focus_window(windows[next]);
    }
}

/// Traz a janela para frente, restaurando se estiver minimizada.
pub fn focus_window(hwnd: HWND) {
    unsafe {
        // Minimizada: SwitchToThisWindow restaura e ativa como o clique na barra de tarefas do
        // Windows. O ShowWindow(SW_RESTORE) de fora deixava apps WinUI 3 maximizados (ex.:
        // WhatsApp) com a interface presa no tamanho de janela minimizada (tela branca), e
        // com app rodando como administrador o UIPI nega o ShowWindow.
        if IsIconic(hwnd).as_bool() {
            SwitchToThisWindow(hwnd, true);
            return;
        }
        let _ = SetForegroundWindow(hwnd);
    }
}

/// As janelas dadas, da mais à frente para a mais atrás.
fn z_order(windows: &[HWND]) -> Vec<HWND> {
    let mut all: Vec<HWND> = Vec::new();
    unsafe {
        let _ = EnumWindows(Some(enum_cb), LPARAM(&mut all as *mut _ as isize));
    }
    all.retain(|h| windows.contains(h));
    all
}

/// Título da janela para o menu, cortado em ~60 caracteres.
pub fn menu_title(hwnd: HWND) -> String {
    let mut buf = [0u16; 512];
    let len = unsafe { GetWindowTextW(hwnd, &mut buf) }.max(0) as usize;
    let title = String::from_utf16_lossy(&buf[..len]);
    let mut out: String = title.chars().take(60).collect();
    if title.chars().count() > 60 {
        out.pop();
        out.push('…');
    }
    // & no menu vira atalho de teclado: dobra para aparecer como texto.
    out.replace('&', "&&")
}

/// Fixa ou desafixa o app no dock e no pinned.txt (comentários e demais linhas ficam como estão).
/// Fixados ficam antes dos abertos: o recém-fixado vai para o fim do grupo dos fixados.
pub fn set_pinned(apps: &mut Vec<App>, key: &str, pin: bool) {
    let Some(i) = apps.iter().position(|a| a.key == key) else { return };
    if apps[i].pinned == pin || apps[i].source == START {
        return;
    }
    let cfg = config_path();
    let mut text = std::fs::read_to_string(&cfg).unwrap_or_default();
    let source = apps[i].source.clone();
    if pin {
        let nl = if text.contains("\r\n") { "\r\n" } else { "\n" };
        if !text.is_empty() && !text.ends_with('\n') {
            text.push_str(nl);
        }
        text.push_str(&source);
        text.push_str(nl);
    } else {
        text = text.split_inclusive('\n').filter(|l| l.trim() != source).collect();
    }
    if let Some(dir) = cfg.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    let _ = std::fs::write(&cfg, text);

    let mut app = apps.remove(i);
    app.pinned = pin;
    if pin || !app.windows.is_empty() {
        let at = apps.iter().filter(|a| a.pinned && a.source != START).count();
        apps.insert(at, app);
    }
}

thread_local! {
    /// Menu do Windows aberto por "Mais opções…": recebe as mensagens dos submenus dinâmicos.
    static SHELL_MENU: std::cell::RefCell<Option<IContextMenu3>> = const { std::cell::RefCell::new(None) };
}

/// Mostra o menu de contexto do próprio Windows para o app (o mesmo do clique direito no
/// Explorer) e executa a opção escolhida.
pub fn shell_menu(hwnd: HWND, source: &str, pt: POINT, flags: TRACK_POPUP_MENU_FLAGS) {
    unsafe {
        let Ok(item) = SHCreateItemFromParsingName::<_, _, IShellItem>(&HSTRING::from(source), None) else { return };
        let Ok(cm) = item.BindToHandler::<_, IContextMenu>(None, &BHID_SFUIObject) else { return };
        let Ok(menu) = CreatePopupMenu() else { return };
        const FIRST: u32 = 1;
        if cm.QueryContextMenu(menu, 0, FIRST, 0x7FFF, CMF_NORMAL).is_ok() {
            SHELL_MENU.with(|m| *m.borrow_mut() = cm.cast::<IContextMenu3>().ok());
            let _ = SetForegroundWindow(hwnd);
            let cmd = TrackPopupMenu(menu, flags, pt.x, pt.y, None, hwnd, None).0 as u32;
            SHELL_MENU.with(|m| *m.borrow_mut() = None);
            if cmd >= FIRST {
                let info = CMINVOKECOMMANDINFO {
                    cbSize: std::mem::size_of::<CMINVOKECOMMANDINFO>() as u32,
                    hwnd,
                    lpVerb: PCSTR((cmd - FIRST) as usize as *const u8),
                    nShow: SW_SHOWNORMAL.0,
                    ..Default::default()
                };
                let _ = cm.InvokeCommand(&info);
            }
        }
        let _ = DestroyMenu(menu);
    }
}

/// Repassa ao menu do Windows aberto as mensagens que montam/desenham os submenus dele.
pub fn shell_menu_msg(msg: u32, wp: WPARAM, lp: LPARAM) -> Option<LRESULT> {
    if !matches!(msg, WM_INITMENUPOPUP | WM_DRAWITEM | WM_MEASUREITEM | WM_MENUCHAR) {
        return None;
    }
    SHELL_MENU.with(|m| {
        let m = m.borrow();
        let cm = m.as_ref()?;
        let mut r = LRESULT(0);
        unsafe { cm.HandleMenuMsg2(msg, wp, lp, Some(&mut r)) }.ok()?;
        Some(r)
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn store_app_id_reads_the_package_manifest() {
        let root = std::env::temp_dir().join(format!("arcdock-test-{}", std::process::id())).join("WindowsApps");
        let pkg = root.join("5319275A.WhatsAppDesktop_2.2645.101.0_x64__cv1g1gvanyjgm");
        std::fs::create_dir_all(&pkg).unwrap();
        std::fs::write(
            pkg.join("AppxManifest.xml"),
            r#"<Applications><Application Id="Other" Executable="Tool.exe"></Application><Application Id="App" Executable="WhatsApp.Root.exe" EntryPoint="Windows.FullTrustApplication"></Application></Applications>"#,
        )
        .unwrap();
        let exe = pkg.join("WhatsApp.Root.exe").display().to_string();
        assert_eq!(
            store_app_id(&exe).as_deref(),
            Some("shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App")
        );
        assert_eq!(store_app_id(&pkg.join("Missing.exe").display().to_string()), None);
        assert_eq!(store_app_id(r"C:\Program Files\App\app.exe"), None);
        let _ = std::fs::remove_dir_all(root.parent().unwrap());
    }
}
