use std::cell::RefCell;
use std::path::Path;

use windows::Win32::Foundation::{HWND, POINT};
use windows::Win32::Graphics::Gdi::{GetMonitorInfoW, MONITORINFO, MONITOR_DEFAULTTONEAREST, MonitorFromPoint};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::core::{HSTRING, w};

use crate::render::Direction;

struct Label {
    owner: HWND,
    hwnd: HWND,
    source: String,
    width: i32,
    height: i32,
}

thread_local! { static LABEL: RefCell<Option<Label>> = const { RefCell::new(None) }; }

fn name(source: &str) -> String {
    if source == crate::apps::START { return "Pesquisar aplicativos".into(); }
    if source == crate::apps::SETTINGS { return "Configurações".into(); }
    if let Some(name) = crate::apps::display_name(source) { return name; }
    Path::new(source).file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(||source.into())
}

pub fn show(owner: HWND, source: &str, at: POINT, edge: Direction) {
    LABEL.with(|cell| {
        let mut label = cell.borrow_mut();
        unsafe {
            let monitor = MonitorFromPoint(at,MONITOR_DEFAULTTONEAREST);
            let mut info = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
            if !GetMonitorInfoW(monitor,&mut info).as_bool() { return; }
            let area=info.rcWork;
            if label.as_ref().is_none_or(|l| l.owner!=owner || l.source!=source) {
                if let Some(old)=label.take() { let _=DestroyWindow(old.hwnd); }
                let name=name(source);
                let scale=crate::monitor_scale(monitor);
                let width=((name.chars().count() as f32 * 8.0 + 24.0)*scale).round() as i32;
                let width=width.clamp(32,(area.right-area.left).clamp(32,420));
                let height=(28.0*scale).round() as i32;
                let Ok(instance)=GetModuleHandleW(None) else { return; };
                let Ok(hwnd)=CreateWindowExW(WS_EX_NOACTIVATE | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT,
                    w!("Static"), &HSTRING::from(name), WS_POPUP | WS_BORDER | WINDOW_STYLE(0x0201),
                    0,0,width,height,Some(owner),None,Some(instance.into()),None) else {return;};
                let font=windows::Win32::Graphics::Gdi::GetStockObject(windows::Win32::Graphics::Gdi::DEFAULT_GUI_FONT);
                SendMessageW(hwnd,WM_SETFONT,Some(windows::Win32::Foundation::WPARAM(font.0 as usize)),None);
                *label=Some(Label {owner,hwnd,source:source.into(),width,height});
            }
            if let Some(l)=label.as_ref() {
                let (x,y)=match edge {
                    Direction::Bottom => (at.x-l.width/2,at.y-l.height),
                    Direction::Top => (at.x-l.width/2,at.y),
                    Direction::Left => (at.x,at.y-l.height/2),
                    Direction::Right => (at.x-l.width,at.y-l.height/2),
                };
                let x=x.clamp(area.left,(area.right-l.width).max(area.left));
                let y=y.clamp(area.top,(area.bottom-l.height).max(area.top));
                let _=SetWindowPos(l.hwnd,Some(HWND_TOPMOST),x,y,l.width,l.height,SWP_NOACTIVATE|SWP_SHOWWINDOW);
            }
        }
    });
}

pub fn hide(owner: HWND) {
    LABEL.with(|cell| {
        let mut label=cell.borrow_mut();
        if label.as_ref().is_some_and(|l| l.owner==owner) && let Some(l)=label.take() {
            unsafe { let _=DestroyWindow(l.hwnd); }
        }
    });
}

