use std::cell::RefCell;
use std::path::Path;

use tiny_skia::{FillRule, Pixmap, Stroke, Transform};
use windows::Win32::Foundation::{COLORREF, HWND, POINT, SIZE};
use windows::Win32::Graphics::DirectWrite::DWRITE_TEXT_ALIGNMENT_CENTER;
use windows::Win32::Graphics::Gdi::{AC_SRC_ALPHA, AC_SRC_OVER, BLENDFUNCTION};
use windows::Win32::Graphics::Gdi::{GetMonitorInfoW, MONITORINFO, MONITOR_DEFAULTTONEAREST, MonitorFromPoint};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::core::{HSTRING, w};

use crate::panel::{Buffer, Font, Text, TextOp};
use crate::render::{Direction, rounded_rect, solid};

struct Label {
    owner: HWND,
    hwnd: HWND,
    source: String,
    width: i32,
    height: i32,
    side: bool,
    light: bool,
    scale: f32,
}

thread_local! { static LABEL: RefCell<Option<Label>> = const { RefCell::new(None) }; }

fn name(source: &str) -> String {
    if source == crate::apps::START { return "Pesquisar aplicativos".into(); }
    if source == crate::apps::SETTINGS { return "Configurações".into(); }
    if let Some(name) = crate::apps::display_name(source) { return name; }
    Path::new(source).file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_else(||source.into())
}

pub fn show(owner: HWND, source: &str, at: POINT, edge: Direction) {
    show_label(owner, source, at, edge, false);
}

pub fn show_side(owner: HWND, source: &str, at: POINT, edge: Direction) {
    show_label(owner, source, at, edge, true);
}

fn show_label(owner: HWND, source: &str, at: POINT, edge: Direction, side: bool) {
    LABEL.with(|cell| {
        let mut label = cell.borrow_mut();
        unsafe {
            let monitor = MonitorFromPoint(at,MONITOR_DEFAULTTONEAREST);
            let mut info = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
            if !GetMonitorInfoW(monitor,&mut info).as_bool() { return; }
            let area=info.rcWork;
            let scale = crate::monitor_scale(monitor);
            let light = crate::light_theme();
            if label.as_ref().is_none_or(|l| l.owner != owner || l.source != source
                || l.side != side || l.light != light || l.scale != scale)
            {
                if let Some(old)=label.take() { let _=DestroyWindow(old.hwnd); }
                let name=name(source);
                let limit = area.right - area.left;
                let bubble = side.then(|| render_bubble(&name, scale, light, limit)).flatten();
                if side && bubble.is_none() { return; }
                let (width, height) = bubble.as_ref().map_or_else(|| (
                    (((name.chars().count() as f32 * 8.0 + 24.0)*scale).round() as i32).clamp(32,limit.clamp(32,420)),
                    (28.0*scale).round() as i32,
                ), |buffer| (buffer.w, buffer.h));
                let Ok(instance) = GetModuleHandleW(None) else { return; };
                let mut ex = WS_EX_NOACTIVATE | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT;
                let mut style = WS_POPUP;
                if side { ex |= WS_EX_LAYERED; } else { style |= WS_BORDER | WINDOW_STYLE(0x0201); }
                let Ok(hwnd) = CreateWindowExW(ex, w!("Static"), &HSTRING::from(name), style,
                    0, 0, width, height, Some(owner), None, Some(instance.into()), None) else { return; };
                if let Some(buffer) = bubble {
                    let size = SIZE { cx: width, cy: height };
                    let blend = BLENDFUNCTION { BlendOp: AC_SRC_OVER as u8, BlendFlags: 0,
                        SourceConstantAlpha: 255, AlphaFormat: AC_SRC_ALPHA as u8 };
                    if UpdateLayeredWindow(hwnd, None, None, Some(&size), Some(buffer.memdc),
                        Some(&POINT::default()), COLORREF(0), Some(&blend), ULW_ALPHA).is_err()
                    {
                        let _ = DestroyWindow(hwnd);
                        return;
                    }
                } else {
                    let font = windows::Win32::Graphics::Gdi::GetStockObject(windows::Win32::Graphics::Gdi::DEFAULT_GUI_FONT);
                    SendMessageW(hwnd, WM_SETFONT, Some(windows::Win32::Foundation::WPARAM(font.0 as usize)), None);
                }
                *label = Some(Label { owner, hwnd, source: source.into(), width, height, side, light, scale });
            }
            if let Some(l)=label.as_ref() {
                let (x,y)=match edge {
                    Direction::Bottom => (at.x-l.width/2,at.y-l.height),
                    Direction::Top => (at.x-l.width/2,at.y),
                    Direction::Left => (at.x,at.y-l.height/2),
                    Direction::Right => (at.x-l.width,at.y-l.height/2),
                };
                let x=x.clamp(area.left,(area.right-l.width).max(area.left));
                let y=y.clamp(area.top,(area.bottom-l.height).max(area.top));
                let _=SetWindowPos(l.hwnd,Some(HWND_TOPMOST),x,y,l.width,l.height,SWP_NOACTIVATE|SWP_SHOWWINDOW);
            }
        }
    });
}

fn render_bubble(name: &str, scale: f32, light: bool, limit: i32) -> Option<Buffer> {
    let painter = Text::new(scale).ok()?;
    let text: Vec<_> = name.encode_utf16().collect();
    let width = ((painter.measure(&text, Font::Bold)? + 32.0 * scale).ceil() as i32)
        .clamp(32, limit.clamp(32, (360.0 * scale) as i32));
    let height = (38.0 * scale).ceil() as i32;
    let mut image = Pixmap::new(width as u32, height as u32)?;
    let (bg, border, ink) = if light {
        ([252, 252, 252, 250], [0, 0, 0, 38], [0.10, 0.10, 0.10, 1.0])
    } else {
        ([32, 32, 32, 249], [255, 255, 255, 60], [0.97, 0.97, 0.97, 1.0])
    };
    let w = width as f32;
    let h = height as f32;
    let shadow = rounded_rect(2.0 * scale, 4.0 * scale, w - 4.0 * scale, h - 5.0 * scale, 13.0 * scale)?;
    let capsule = rounded_rect(3.0 * scale, 2.0 * scale, w - 6.0 * scale, h - 7.0 * scale, 12.0 * scale)?;
    let identity = Transform::identity();
    image.fill_path(&shadow, &solid([0, 0, 0, 55]), FillRule::Winding, identity, None);
    image.fill_path(&capsule, &solid(bg), FillRule::Winding, identity, None);
    image.stroke_path(&capsule, &solid(border), &Stroke { width: scale, ..Default::default() }, identity, None);
    let buffer = Buffer::new(width, height)?;
    let bytes = unsafe { std::slice::from_raw_parts_mut(buffer.bits, image.data().len()) };
    for (dest, pixel) in bytes.chunks_exact_mut(4).zip(image.data().chunks_exact(4)) {
        dest.copy_from_slice(&[pixel[2], pixel[1], pixel[0], pixel[3]]);
    }
    let inset = (15.0 * scale).min(w * 0.38);
    painter.draw(buffer.memdc, width, height, &[TextOp {
        text, font: Font::Bold, rect: [inset, 2.0 * scale, w - 2.0 * inset, h - 7.0 * scale],
        align: DWRITE_TEXT_ALIGNMENT_CENTER, color: ink, wrap: false, clip: None,
    }]);
    Some(buffer)
}

pub fn hide(owner: HWND) {
    LABEL.with(|cell| {
        let mut label=cell.borrow_mut();
        if label.as_ref().is_some_and(|l| l.owner==owner) && let Some(l)=label.take() {
            unsafe { let _=DestroyWindow(l.hwnd); }
        }
    });
}

