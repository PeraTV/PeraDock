use std::cell::RefCell;
use std::path::Path;
use std::time::Instant;

use tiny_skia::{Pixmap, Rect, Transform};
use windows::Win32::Foundation::{COLORREF, HWND, LPARAM, LRESULT, POINT, RECT, SIZE, WPARAM};
use windows::Win32::Graphics::Gdi::{AC_SRC_ALPHA, AC_SRC_OVER, BLENDFUNCTION, GetMonitorInfoW, HMONITOR, MONITOR_DEFAULTTONULL, MONITOR_DEFAULTTOPRIMARY, MONITORINFO, MonitorFromWindow, ValidateRect};
use windows::Win32::System::Com::{CLSCTX_INPROC_SERVER, CoCreateInstance, CoTaskMemFree};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::Dialogs::{CC_FULLOPEN, CC_RGBINIT, CHOOSECOLORW, ChooseColorW};
use windows::Win32::UI::Shell::{DragAcceptFiles, DragFinish, DragQueryFileW, HDROP, FOS_FILEMUSTEXIST, FOS_FORCEFILESYSTEM, FileOpenDialog, IFileOpenDialog, SIGDN_FILESYSPATH};
use windows::Win32::UI::WindowsAndMessaging::*;
use windows::Win32::UI::Input::KeyboardAndMouse::{GetCapture, ReleaseCapture, SetCapture};
use windows::core::w;

use crate::{apps::{self, App}, config, glass::Glass, render::{self, Direction, Metrics, Theme}};
use crate::panel::Buffer;

const TIMER_HOVER: usize = 1;
const TIMER_REFRESH: usize = 2;
const TIMER_VISIBILITY: usize = 3;
const REFLOW_TIME: f32 = 0.065;

struct Press {
    home: usize,
    row: usize,
    start: f32,
    grab: f32,
    cursor: f32,
    centers: Vec<f32>,
}

impl Press {
    fn dragging(&self) -> bool { !self.centers.is_empty() }
}

#[derive(Default)]
struct State {
    window: HWND,
    monitor: HMONITOR,
    monitor_bounds: RECT,
    bounds: RECT,
    visible: bool,
    edge: Direction,
    move_pressed: bool,
    press: Option<Press>,
    offsets: Vec<f32>,
    last_frame: Option<Instant>,
    peek: bool,
    foreground: HWND,
    glass: HWND,
    glass_fx: Option<Glass>,
    glass_rect: Option<(i32, i32, i32, i32)>,
    entries: Vec<App>,
    separators: Vec<String>,
    first: usize,
    capacity: usize,
    tracking: bool,
    mouse: f32,
    hover: f32,
    scale: f32,
    width: i32,
    length: i32,
    raster: Option<(Pixmap, Buffer)>,
}

impl State {
    fn metrics(&self) -> Metrics { Metrics::side(self.scale, config::side_icon_size(), config::side_animate()) }

    fn visible_count(&self) -> usize { self.entries.len().min(self.capacity) }

    fn visible_separators(&self) -> Vec<usize> {
        self.entries.iter().skip(self.first).take(self.visible_count()).enumerate()
            .filter_map(|(index, app)| self.separators.contains(&app.source).then_some(index)).collect()
    }

    fn slots(&self, m: &Metrics, separators: &[usize]) -> Vec<render::Slot> {
        let mouse = self.press.as_ref().filter(|p| p.dragging()).map_or(self.mouse, |p| p.start);
        render::layout(self.visible_count() + 1, separators, self.length as f32, m, mouse, self.hover)
    }

    fn shown_slots(&self, mut slots: Vec<render::Slot>) -> Vec<render::Slot> {
        for (slot, offset) in slots.iter_mut().zip(&self.offsets) { slot.dx = *offset; }
        if let Some(press) = self.press.as_ref().filter(|p| p.dragging()) {
            let min = press.centers[0];
            let max = press.centers[press.centers.len() - 1];
            let center = (press.cursor - press.grab).clamp(min, max);
            let slot = &mut slots[press.row];
            slot.dx = center - slot.x - slot.size / 2.0;
        }
        slots
    }

    fn current_slots(&self) -> Vec<render::Slot> {
        self.slots(&self.metrics(), &self.visible_separators())
    }

    fn visual_positions(&self) -> Vec<f32> {
        self.shown_slots(self.current_slots()).iter().map(|slot| slot.x + slot.dx).collect()
    }

    fn set_reflow(&mut self, before: Vec<f32>) {
        self.offsets = before.into_iter().zip(self.current_slots())
            .map(|(x, slot)| x - slot.x).collect();
        self.last_frame = Some(Instant::now());
    }

    fn start_press(&mut self, row: usize, cursor: f32) {
        let slots = self.shown_slots(self.current_slots());
        let slot = &slots[row];
        self.press = Some(Press {
            home: row, row, start: cursor,
            grab: cursor - slot.x - slot.dx - slot.size / 2.0,
            cursor, centers: Vec::new(),
        });
    }

    fn move_press(&mut self, cursor: f32) -> bool {
        let Some(press) = &self.press else { return false; };
        if !press.dragging() && (cursor - press.start).abs() < 5.0 * self.scale {
            return false;
        }
        if !press.dragging() {
            let m = self.metrics();
            let centers = render::layout(self.visible_count() + 1, &self.visible_separators(),
                self.length as f32, &m, press.start, self.hover).into_iter()
                .take(self.visible_count()).map(|slot| slot.x + slot.size / 2.0).collect();
            self.press.as_mut().unwrap().centers = centers;
        }
        let press = self.press.as_mut().unwrap();
        press.cursor = cursor;
        let center = cursor - press.grab;
        let row = press.centers.windows(2).take_while(|pair| center >= (pair[0] + pair[1]) / 2.0).count();
        let from = press.row;
        if from != row {
            let mut before = self.visual_positions();
            let app = self.entries.remove(self.first + from);
            self.entries.insert(self.first + row, app);
            let x = before.remove(from);
            before.insert(row, x);
            self.press.as_mut().unwrap().row = row;
            self.set_reflow(before);
        }
        true
    }

    fn finish_press(&mut self, commit: bool) -> bool {
        let Some(press) = &self.press else { return false; };
        if !press.dragging() {
            self.press = None;
            return false;
        }
        let mut before = self.visual_positions();
        let press = self.press.take().unwrap();
        if press.home != press.row {
            let saved = commit && save(&self.entries.iter().map(|app| app.source.clone()).collect::<Vec<_>>()).is_ok();
            if !saved {
                let app = self.entries.remove(self.first + press.row);
                self.entries.insert(self.first + press.home, app);
                let x = before.remove(press.row);
                before.insert(press.home, x);
            }
        }
        self.set_reflow(before);
        true
    }

    fn step_reflow(&mut self) -> bool {
        let Some(last) = self.last_frame.replace(Instant::now()) else {
            self.last_frame = None;
            return false;
        };
        let remaining = (-last.elapsed().as_secs_f32() / REFLOW_TIME).exp();
        for offset in &mut self.offsets { *offset *= remaining; }
        if self.offsets.iter().any(|value| value.abs() > 0.3) { return true; }
        self.offsets.clear();
        self.last_frame = None;
        false
    }

    fn axis(&self, lp: LPARAM) -> f32 {
        if self.edge.vertical() { ((lp.0 >> 16) as i16) as f32 } else { (lp.0 as i16) as f32 }
    }

    fn hit(&self, lp: LPARAM) -> Option<usize> {
        let y = self.axis(lp);
        let m = self.metrics();
        self.slots(&m, &self.visible_separators()).iter().position(|slot| y >= slot.x - m.gap / 2.0
            && y < slot.x + slot.size + m.gap / 2.0)
    }
}

thread_local! { static DOCK: RefCell<State> = RefCell::new(State::default()); }

fn path() -> std::path::PathBuf { apps::config_path().with_file_name("dock-lateral.txt") }

fn save(list: &[String]) -> std::io::Result<()> {
    let path = path();
    if let Some(parent) = path.parent() { std::fs::create_dir_all(parent)?; }
    std::fs::write(path, list.join("\n") + "\n")
}

fn read() -> Vec<String> {
    std::fs::read_to_string(path()).unwrap_or_default().lines().map(str::trim)
        .filter(|line| !line.is_empty() && Path::new(line).is_file()).map(str::to_owned).collect()
}

pub fn count() -> usize { read().len() }

fn separators_path() -> std::path::PathBuf { path().with_file_name("dock-lateral-separadores.txt") }

fn read_separators() -> Vec<String> {
    std::fs::read_to_string(separators_path()).unwrap_or_default().lines().map(str::to_owned).collect()
}

fn save_separators(separators: &[String]) -> std::io::Result<()> {
    std::fs::write(separators_path(), separators.join("\n"))
}

pub fn add(owner: HWND) {
    let selected = unsafe {
        (|| -> windows::core::Result<String> {
            let picker: IFileOpenDialog = CoCreateInstance(&FileOpenDialog, None, CLSCTX_INPROC_SERVER)?;
            picker.SetTitle(w!("Adicionar aplicativo ou atalho à Dock 2"))?;
            picker.SetOptions(picker.GetOptions()? | FOS_FORCEFILESYSTEM | FOS_FILEMUSTEXIST)?;
            picker.SetFileTypes(&[windows::Win32::UI::Shell::Common::COMDLG_FILTERSPEC {
                pszName: w!("Aplicativos e atalhos"),
                pszSpec: w!("*.exe;*.lnk;*.url"),
            }])?;
            picker.Show(Some(owner))?;
            let result = picker.GetResult()?.GetDisplayName(SIGDN_FILESYSPATH)?;
            let selected = result.to_string();
            CoTaskMemFree(Some(result.0.cast()));
            Ok(selected?)
        })()
    };
    if let Ok(selected) = selected { add_paths([selected]); }
}

fn add_paths(files: impl IntoIterator<Item = String>) {
    let mut entries = read();
    let initial = entries.len();
    for file in files {
        let path = Path::new(&file);
        let allowed = path.extension().and_then(|x| x.to_str())
            .is_some_and(|x| ["exe", "lnk", "url"].iter().any(|kind| x.eq_ignore_ascii_case(kind)));
        if allowed && !file.contains(['\n', '\r']) && path.is_file()
            && !entries.iter().any(|entry| entry.eq_ignore_ascii_case(&file))
        {
            entries.push(file);
        }
    }
    if initial != entries.len() && save(&entries).is_ok() { sync(); }
}

fn drop_files(drop: HDROP) {
    let mut files = Vec::new();
    unsafe {
        for i in 0..DragQueryFileW(drop, u32::MAX, None) {
            let length = DragQueryFileW(drop, i, None);
            if length == 0 { continue; }
            let mut path = vec![0; length as usize + 1];
            let copied = DragQueryFileW(drop, i, Some(&mut path));
            if copied > 0 { files.push(String::from_utf16_lossy(&path[..copied as usize])); }
        }
        DragFinish(drop);
    }
    add_paths(files);
}

pub fn sync() {
    if !config::side_enabled() {
        shutdown();
        return;
    }
    let mut monitor = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
    let display = unsafe { MonitorFromWindow(HWND::default(), MONITOR_DEFAULTTOPRIMARY) };
    let scale = unsafe {
        if !GetMonitorInfoW(display, &mut monitor).as_bool() { return; }
        crate::monitor_scale(display)
    };
    let mut area = monitor.rcWork;
    let edge = config::dock_edge(true);
    if config::dock_enabled() && config::dock_edge(false) == edge {
        let gap = Metrics::new(scale).window_height();
        match edge {
            Direction::Bottom => area.bottom -= gap,
            Direction::Top => area.top += gap,
            Direction::Left => area.left += gap,
            Direction::Right => area.right -= gap,
        }
    }
    let m = Metrics::side(scale, config::side_icon_size(), config::side_animate());
    let width = m.window_height();
    let axis = if edge.vertical() {area.bottom-area.top} else {area.right-area.left};
    let space = (axis - 2 * m.margin.ceil() as i32).max(1);
    let extra = 4.0 * (m.max - m.base) + 2.0 * m.pad;
    let sources = read();
    let separators: Vec<_> = read_separators().into_iter().filter(|entry| sources.contains(entry)).collect();
    let required_length = |apps: usize| {
        (apps + 1) as f32 * (m.base + m.gap) - m.gap + extra + apps.min(separators.len()) as f32 * m.sep
    };
    let mut capacity = sources.len();
    while capacity > 1 && required_length(capacity) > space as f32 { capacity -= 1; }
    let length = required_length(capacity).ceil().min(space as f32) as i32;
    let current = DOCK.with(|state| state.borrow().window);
    if current.is_invalid() {
        let Some((window, glass, fx)) = create_windows(m.radius) else { return; };
        DOCK.with(|state| {
            let mut state = state.borrow_mut();
            state.window = window;
            state.glass = glass;
            state.glass_fx = fx;
        });
    }
    let POINT {x,y} = edge.origin(area,length,width);
    let (w,h) = edge.dimensions(length,width);
    let window = DOCK.with(|state| {
        let mut state = state.borrow_mut();
        state.press = None;
        state.offsets.clear();
        state.last_frame = None;
        if state.scale != scale || state.entries.iter().map(|app| &app.source).ne(sources.iter()) {
            state.entries = sources.into_iter().map(|source| App {
                key: apps::source_key(&source),
                icon: apps::load_icon(&source, (96.0 * scale).ceil() as i32),
                source,
                pinned: true,
                windows: Vec::new(),
            }).collect();
            apps::refresh_pinned(&mut state.entries);
        }
        if state.scale != scale {
            if let Some(fx) = &state.glass_fx { fx.set_radius(m.radius); }
        }
        if state.width != width || state.length != length || state.edge != edge {
            state.raster = Pixmap::new(w as u32, h as u32).zip(Buffer::new(w, h));
        }
        state.edge = edge;
        state.scale = scale;
        state.width = width;
        state.length = length;
        state.monitor = display;
        state.monitor_bounds = monitor.rcMonitor;
        state.bounds = RECT { left: x, right: x + w, top: y, bottom: y + h };
        state.capacity = capacity;
        state.separators = separators;
        state.first = state.first.min(state.entries.len().saturating_sub(capacity));
        state.glass_rect = None;
        state.window
    });
    unsafe {
        let _ = SetWindowPos(window, Some(HWND_TOPMOST), x, y, w, h, SWP_NOACTIVATE);
        if config::side_autohide() {
            SetTimer(Some(window), TIMER_VISIBILITY, 75, None);
        } else {
            let _ = KillTimer(Some(window), TIMER_VISIBILITY);
        }
    }
    refresh_visibility();
    refresh_appearance();
}

fn create_windows(radius: f32) -> Option<(HWND, HWND, Option<Glass>)> {
    unsafe {
        let instance = GetModuleHandleW(None).ok()?.into();
        let class = w!("PeraDockSide");
        RegisterClassW(&WNDCLASSW {
            lpfnWndProc: Some(window_proc), hInstance: instance, lpszClassName: class,
            hCursor: LoadCursorW(None, IDC_HAND).unwrap_or_default(), ..Default::default()
        });
        let ex = WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
        let glass = CreateWindowExW(ex | WS_EX_NOREDIRECTIONBITMAP | WS_EX_TRANSPARENT,
            w!("ArcDockWinGlass"), w!("PeraDock Glass"), WS_POPUP,
            0, 0, 1, 1, None, None, Some(instance), None).ok()?;
        let Ok(window) = CreateWindowExW(ex | WS_EX_LAYERED, class, w!("PeraDock Dock 2"),
            WS_POPUP, 0, 0, 1, 1, Some(glass), None, Some(instance), None) else {
                let _ = DestroyWindow(glass);
                return None;
            };
        DragAcceptFiles(window, true);
        SetTimer(Some(window), TIMER_REFRESH, 1000, None);
        Some((window, glass, Glass::new(glass, radius).ok()))
    }
}

pub fn refresh_appearance() {
    DOCK.with(|state| {
        let mut state = state.borrow_mut();
        if state.visible {
            draw(&mut state);
        }
    });
}

fn refresh_visibility() {
    let foreground = unsafe { GetForegroundWindow() };
    let mut cursor = POINT::default();
    let cursor = unsafe { GetCursorPos(&mut cursor) }.ok().map(|()| cursor);
    DOCK.with(|state| apply_visibility(&mut state.borrow_mut(), foreground, cursor));
}

fn apply_visibility(state: &mut State, foreground: HWND, cursor: Option<POINT>) {
    if state.window.is_invalid() { return; }
    if state.foreground != foreground {
        state.foreground = foreground;
        state.peek = false;
    }
    let hide_for_app = !state.move_pressed && state.press.is_none() && config::side_autohide() && other_app_on_monitor(foreground, state.monitor);
    if hide_for_app {
        let bounds = state.bounds;
        let screen = state.monitor_bounds;
        state.peek = cursor.is_some_and(|p| {
            let (along, span, depth, reach) = match state.edge {
                Direction::Left => (p.y,bounds.top..bounds.bottom,p.x-screen.left,bounds.right-screen.left),
                Direction::Right => (p.y,bounds.top..bounds.bottom,screen.right-1-p.x,screen.right-bounds.left),
                Direction::Top => (p.x,bounds.left..bounds.right,p.y-screen.top,bounds.bottom-screen.top),
                Direction::Bottom => (p.x,bounds.left..bounds.right,screen.bottom-1-p.y,screen.bottom-bounds.top),
            };
            span.contains(&along) && ((0..6).contains(&depth) || (state.peek && (0..reach).contains(&depth)))
        });
    } else {
        state.peek = false;
    }
    let visible = !hide_for_app || state.peek;
    if visible == state.visible { return; }
    state.visible = visible;
    state.glass_rect = None;
    unsafe {
        if visible {
            draw(state);
            let _ = ShowWindow(state.window, SW_SHOWNOACTIVATE);
        } else {
            crate::dock_label::hide(state.window);
            state.hover = 0.0;
            state.offsets.clear();
            state.last_frame = None;
            state.tracking = false;
            let _ = KillTimer(Some(state.window), TIMER_HOVER);
            let _ = ShowWindow(state.window, SW_HIDE);
            let _ = ShowWindow(state.glass, SW_HIDE);
        }
    }
}

fn other_app_on_monitor(window: HWND, monitor: HMONITOR) -> bool {
    unsafe {
        if window.is_invalid() || window == GetShellWindow() || window == GetDesktopWindow()
            || !IsWindowVisible(window).as_bool() || IsIconic(window).as_bool()
            || MonitorFromWindow(window, MONITOR_DEFAULTTONULL) != monitor
        {
            return false;
        }
        let mut pid = 0;
        GetWindowThreadProcessId(window, Some(&mut pid));
        if pid == std::process::id() { return false; }
        let mut class = [0u16; 64];
        let size = GetClassNameW(window, &mut class).max(0) as usize;
        ![w!("Progman"), w!("WorkerW"), w!("Shell_TrayWnd"), w!("Shell_SecondaryTrayWnd")]
            .iter().any(|name| name.as_wide() == &class[..size])
    }
}

pub fn pick_color(owner: HWND) {
    let [r, g, b] = config::side_color().unwrap_or_else(|| {
        if crate::light_theme() { [250, 250, 252] } else { [40, 40, 44] }
    });
    let mut custom = [COLORREF(0x00FFFFFF); 16];
    let mut choice = CHOOSECOLORW {
        lStructSize: size_of::<CHOOSECOLORW>() as u32,
        hwndOwner: owner,
        rgbResult: COLORREF(u32::from(r) | u32::from(g) << 8 | u32::from(b) << 16),
        lpCustColors: custom.as_mut_ptr(),
        Flags: CC_RGBINIT | CC_FULLOPEN,
        ..Default::default()
    };
    if unsafe { ChooseColorW(&mut choice) }.as_bool() {
        let color = choice.rgbResult.0;
        config::set_side_color(Some([color as u8, (color >> 8) as u8, (color >> 16) as u8]));
        refresh_appearance();
    }
}

fn animate_tick() -> bool {
    DOCK.with(|state| {
        let mut state = state.borrow_mut();
        let sliding = state.step_reflow();
        if state.press.as_ref().is_some_and(Press::dragging) { return true; }
        let target = if state.tracking && config::side_animate() { 1.0 } else { 0.0 };
        state.hover += (target - state.hover) * 0.25;
        if (target - state.hover).abs() < 0.015 {
            state.hover = target;
            sliding
        } else {
            true
        }
    })
}

pub fn shutdown() {
    let mut state = DOCK.with(|state| std::mem::take(&mut *state.borrow_mut()));
    state.glass_fx = None;
    if !state.window.is_invalid() {
        unsafe {
            crate::dock_label::hide(state.window);
        let _ = DestroyWindow(state.window);
            let _ = DestroyWindow(state.glass);
        }
    }
}

fn draw(state: &mut State) {
    let m = state.metrics();
    let separators = state.visible_separators();
    let slots = state.shown_slots(state.slots(&m, &separators));
    let dragged = state.press.as_ref().filter(|p| p.dragging()).map(|p| p.row);
    let direction = state.edge;
    let light = crate::light_theme();
    let percent = config::side_transparency();
    let color = config::side_color();
    let theme = Theme::new(light, crate::accent_color()).side(percent, color, config::side_border());
    let contrast = color.filter(|_| percent < 45.0)
        .map_or(light, |[r, g, b]| u32::from(r) * 299 + u32::from(g) * 587 + u32::from(b) * 114 >= 145_000);
    let mut origin = windows::Win32::Foundation::RECT::default();
    if unsafe { GetWindowRect(state.window, &mut origin) }.is_err() { return; }
    let glass_rect = render::box_rect(&slots, &m, state.width as f32)
        .map(|(l, t, r, b)| direction.rect(l, t, r, b, state.width))
        .map(|(l, t, r, b)| (origin.left + l, origin.top + t, r - l, b - t));
    if let Some(fx) = &state.glass_fx {
        fx.set_opacity(((100.0 - percent) / 88.0).min(1.0));
        if state.glass_rect != glass_rect && let Some((x, y, w, h)) = glass_rect {
            fx.resize(w as f32, h as f32);
            unsafe {
                let _ = SetWindowPos(state.glass, None, x, y, w, h,
                    SWP_NOACTIVATE | SWP_NOZORDER | SWP_SHOWWINDOW);
            }
        }
    }
    state.glass_rect = glass_rect;
    let add = App {
        source: String::new(), key: String::new(), pinned: true,
        icon: add_icon(contrast), windows: Vec::new(),
    };
    let items: Vec<&App> = state.entries.iter().skip(state.first).take(state.visible_count())
        .chain(std::iter::once(&add)).collect();
    let fg = unsafe { GetForegroundWindow() };
    let focus = items.iter().position(|app| app.windows.contains(&fg));
    let Some((image, buffer)) = &mut state.raster else { return; };
    render::draw_oriented(image, &slots, &separators, &items, &m, &theme, state.hover, focus,
        state.tracking || state.last_frame.is_some(), direction, dragged);
    let bytes = unsafe { std::slice::from_raw_parts_mut(buffer.bits, image.data().len()) };
    for (d, s) in bytes.chunks_exact_mut(4).zip(image.data().chunks_exact(4)) {
        d.copy_from_slice(&[s[2], s[1], s[0], s[3]]);
    }
    let size = SIZE { cx: buffer.w, cy: buffer.h };
    let blend = BLENDFUNCTION { BlendOp: AC_SRC_OVER as u8, BlendFlags: 0,
        SourceConstantAlpha: 255, AlphaFormat: AC_SRC_ALPHA as u8 };
    unsafe {
        let _ = UpdateLayeredWindow(state.window, None, None, Some(&size), Some(buffer.memdc),
            Some(&POINT::default()), COLORREF(0), Some(&blend), ULW_ALPHA);
    }
}

fn add_icon(light: bool) -> Option<Pixmap> {
    let mut icon = Pixmap::new(48, 48)?;
    let mut paint = tiny_skia::Paint::default();
    let value = if light { 38 } else { 241 };
    paint.set_color_rgba8(value, value, value, 240);
    for (x, y, width, height) in [(12.0, 22.5, 24.0, 3.0), (22.5, 12.0, 3.0, 24.0)] {
        icon.fill_rect(Rect::from_xywh(x, y, width, height)?, &paint, Transform::identity(), None);
    }
    Some(icon)
}

fn show_label(hwnd: HWND, lp: LPARAM) {
    let item = DOCK.with(|state| {
        let state = state.borrow();
        if state.press.is_some() || state.move_pressed { return None; }
        let i = state.hit(lp)?;
        if i >= state.visible_count() { return None; }
        let app = state.entries.get(state.first+i)?;
        let m=state.metrics();
        let slots=state.slots(&m,&state.visible_separators());
        let slot=slots.get(i)?;
        let cross=state.width as f32;
        let (x,y)=state.edge.coords(slot.x+slot.size/2.0,cross-m.margin-m.pad-slot.size-8.0*state.scale,cross);
        let anchor=POINT{x:state.bounds.left+x.round() as i32,y:state.bounds.top+y.round() as i32};
        Some((app.source.clone(),anchor,state.edge))
    });
    if let Some((source,anchor,edge))=item { crate::dock_label::show_side(hwnd,&source,anchor,edge); }
    else { crate::dock_label::hide(hwnd); }
}

unsafe extern "system" fn window_proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    unsafe {
        match msg {
            WM_PAINT => { let _ = ValidateRect(Some(hwnd), None); }
            WM_DROPFILES => drop_files(HDROP(wp.0 as *mut std::ffi::c_void)),
            WM_TIMER if wp.0 == TIMER_HOVER => {
                if !animate_tick() { let _ = KillTimer(Some(hwnd), TIMER_HOVER); }
                refresh_appearance();
            }
            WM_TIMER if wp.0 == TIMER_VISIBILITY => refresh_visibility(),
            WM_TIMER if wp.0 == TIMER_REFRESH => {
                DOCK.with(|state| { apps::refresh_pinned(&mut state.borrow_mut().entries); });
                refresh_appearance();
            }
            WM_MOUSEACTIVATE => return LRESULT(MA_NOACTIVATE as isize),
            WM_ERASEBKGND => return LRESULT(1),
            WM_MOUSEMOVE | 0x02a3 => {
                let (started, dragging, drag_began) = DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    let started = !state.tracking && msg == WM_MOUSEMOVE;
                    if started {
                        use windows::Win32::UI::Input::KeyboardAndMouse::*;
                        let mut event = TRACKMOUSEEVENT {
                            cbSize: size_of::<TRACKMOUSEEVENT>() as u32, dwFlags: TME_LEAVE,
                            hwndTrack: hwnd, dwHoverTime: 0,
                        };
                        let _ = TrackMouseEvent(&mut event);
                    }
                    state.tracking = msg == WM_MOUSEMOVE;
                    let axis = state.axis(lp);
                    let was_dragging = state.press.as_ref().is_some_and(Press::dragging);
                    let dragging = state.tracking && state.move_press(axis);
                    if state.tracking { state.mouse = axis; }
                    (started, dragging, dragging && !was_dragging)
                });
                if msg == 0x02a3 || dragging || !config::dock_show_names(true) {
                    crate::dock_label::hide(hwnd);
                } else {
                    show_label(hwnd, lp);
                }
                let zoom = config::side_animate();
                if drag_began || zoom && (started || msg == 0x02a3) {
                    SetTimer(Some(hwnd), TIMER_HOVER, 16, None);
                }
                if dragging || zoom { refresh_appearance(); }
            }
            WM_MOUSEWHEEL => {
                crate::dock_label::hide(hwnd);
                DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    if state.press.is_some() { return; }
                    state.offsets.clear();
                    state.last_frame = None;
                    let steps = ((wp.0 >> 16) as i16 / 120).clamp(-6,6) as isize;
                    let last = state.entries.len().saturating_sub(state.capacity);
                    state.first = state.first.saturating_add_signed(-steps).min(last);
                });
                refresh_appearance();
            }
            WM_CAPTURECHANGED => {
                let cancelled = DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    state.move_pressed = false;
                    state.finish_press(false)
                });
                if cancelled {
                    SetTimer(Some(hwnd), TIMER_HOVER, 16, None);
                    refresh_appearance();
                }
            }
            WM_MBUTTONDOWN => {
                crate::dock_label::hide(hwnd);
                DOCK.with(|state| state.borrow_mut().move_pressed = true);
                SetCapture(hwnd);
            }
            WM_MBUTTONUP => {
                let area = DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    std::mem::take(&mut state.move_pressed).then_some(state.monitor_bounds)
                });
                if GetCapture() == hwnd { let _ = ReleaseCapture(); }
                if let Some(area) = area { crate::finish_dock_move(true,area); }
            }
            WM_LBUTTONDOWN => {
                crate::dock_label::hide(hwnd);
                let pressed = DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    let Some(row) = state.hit(lp) else { return false; };
                    if row >= state.visible_count() { return false; }
                    let cursor = state.axis(lp);
                    state.start_press(row, cursor);
                    true
                });
                if pressed { SetCapture(hwnd); }
            }
            WM_LBUTTONUP => {
                let moved = DOCK.with(|state| {
                    let mut state = state.borrow_mut();
                    let axis = state.axis(lp);
                    state.move_press(axis);
                    state.finish_press(true)
                });
                if GetCapture() == hwnd { let _ = ReleaseCapture(); }
                if moved {
                    SetTimer(Some(hwnd), TIMER_HOVER, 16, None);
                    refresh_appearance();
                    return LRESULT(0);
                }
                let (plus, target) = DOCK.with(|state| {
                    let state = state.borrow();
                    let Some(row) = state.hit(lp) else { return (false, None); };
                    let plus = row == state.visible_count();
                    (plus, state.entries.get(state.first + row).map(|app| (app.source.clone(), app.windows.clone())))
                });
                if plus { add(hwnd); } else if let Some((source, windows)) = target { apps::activate(&source, &windows); }
            }
            WM_RBUTTONUP => {
                let selected = DOCK.with(|state| {
                    let state = state.borrow();
                    let row = state.hit(lp)?;
                    if row >= state.visible_count() { return None; }
                    state.entries.get(state.first + row).map(|app| app.source.clone())
                });
                if let Some(selected) = selected && let Ok(menu) = CreatePopupMenu() {
                    let mut separators = read_separators();
                    let separator = separators.iter().position(|path| path == &selected);
                    let vertical = DOCK.with(|state| state.borrow().edge.vertical());
                    let label = match (separator.is_some(), vertical) {
                        (false,true) => w!("Adicionar separador abaixo"),
                        (true,true) => w!("Remover separador abaixo"),
                        (false,false) => w!("Adicionar separador à direita"),
                        (true,false) => w!("Remover separador à direita"),
                    };
                    let _ = AppendMenuW(menu, MF_STRING, 2, label);
                    let _ = AppendMenuW(menu, MF_STRING, 1, w!("Remover da Dock 2"));
                    let mut point = windows::Win32::Foundation::POINT::default();
                    let _ = GetCursorPos(&mut point);
                    let _ = SetForegroundWindow(hwnd);
                    let chosen = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON, point.x, point.y, None, hwnd, None);
                    let _ = DestroyMenu(menu);
                    if chosen.0 == 1 {
                        let mut list = read();
                        list.retain(|path| path != &selected);
                        if save(&list).is_ok() {
                            separators.retain(|path| path != &selected);
                            let _ = save_separators(&separators);
                            sync();
                        }
                    } else if chosen.0 == 2 {
                        if let Some(position) = separator {
                            separators.remove(position);
                        } else {
                            separators.push(selected);
                        }
                        if save_separators(&separators).is_ok() { sync(); }
                    }
                }
            }
            WM_DISPLAYCHANGE | WM_DPICHANGED => { let _ = PostMessageW(Some(hwnd), WM_APP + 1, WPARAM(0), LPARAM(0)); }
            WM_CLOSE => {
                config::set_side_enabled(false);
                shutdown();
            }
            x if x == WM_APP + 1 => sync(),
            _ => return DefWindowProcW(hwnd,msg,wp,lp),
        }
        LRESULT(0)
    }
}
