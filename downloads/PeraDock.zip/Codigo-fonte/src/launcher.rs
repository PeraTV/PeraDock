//! Lançador do botão Iniciar: busca nos apps instalados (a pasta Aplicativos do Windows,
//! `shell:AppsFolder`, que tem os apps da Store e os atalhos do menu Iniciar).
//!
//! Sem busca, a lista mostra só os apps "úteis" (veja [`useful`]); documentação,
//! desinstaladores e ferramentas de administração só aparecem buscando.

use std::collections::HashMap;
use std::sync::{Arc, LazyLock, Mutex};
use std::time::{Duration, Instant};

use tiny_skia::Pixmap;
use windows::Win32::Foundation::{HWND, LPARAM, POINT, RECT, WPARAM};
use windows::Win32::Graphics::Gdi::{GetMonitorInfoW, MONITOR_DEFAULTTONEAREST, MONITORINFO, MonitorFromPoint};
use windows::Win32::System::Com::{CoTaskMemFree, CoInitializeEx, CoUninitialize, COINIT_APARTMENTTHREADED};
use windows::Win32::UI::HiDpi::GetDpiForSystem;
use windows::Win32::UI::Input::KeyboardAndMouse::{VK_DOWN, VK_UP};
use windows::Win32::UI::Shell::{
    BHID_EnumItems, FOLDERID_AppsFolder, IEnumShellItems, IShellItem, KF_FLAG_DEFAULT, SHGetKnownFolderItem,
    SIGDN_NORMALDISPLAY, SIGDN_PARENTRELATIVEPARSING, ShellExecuteW,
};
use windows::Win32::UI::WindowsAndMessaging::{GetCursorPos, PostMessageW, SW_SHOWNORMAL, WM_APP};
use windows::core::{HSTRING, w};

use crate::apps::{APPS_FOLDER, load_icon};
use crate::panel::{self, Event, PanelContent, Widget};

const FIELD: u32 = 1;
/// Ids das linhas: ROW + posição na lista visível.
const ROW: u32 = 100;
/// Linhas visíveis; o resto rola com as setas ou a roda do mouse.
const VISIBLE: usize = 8;

struct Entry {
    name: String,
    /// Nome em minúsculas, sem acentos (para a busca).
    key: String,
    /// Nome de análise dentro da pasta Aplicativos (AUMID ou caminho).
    id: String,
    /// Aparece na lista sem busca.
    useful: bool,
}

pub const WM_LOADED: u32 = WM_APP + 89;
type IconKey = (String, i32);

#[derive(Default)]
struct Cache {
    entries: Arc<Vec<Entry>>,
    fetched: Option<Instant>,
    icons: HashMap<IconKey, Option<Pixmap>>,
    pending: Vec<IconKey>,
    busy: bool,
    refresh: bool,
}

static CACHE: LazyLock<Mutex<Cache>> = LazyLock::new(|| Mutex::new(Cache::default()));

pub fn preload() {
    let mut cache = CACHE.lock().unwrap();
    if cache.fetched.is_some_and(|at| at.elapsed() < Duration::from_secs(90)) || cache.busy { return; }
    cache.refresh = true;
    drop(cache);
    start_worker();
}

fn start_worker() {
    let hwnd = crate::primary_dock_hwnd().0 as isize;
    if hwnd == 0 { return; }
    let mut cache = CACHE.lock().unwrap();
    if cache.busy || (!cache.refresh && cache.pending.is_empty()) { return; }
    cache.busy = true;
    drop(cache);
    std::thread::spawn(move || {
        let com = unsafe { CoInitializeEx(None, COINIT_APARTMENTTHREADED) };
        let notify = || unsafe {
            let _ = PostMessageW(Some(HWND(hwnd as *mut _)), WM_LOADED, WPARAM(0), LPARAM(0));
        };
        loop {
            let mut cache = CACHE.lock().unwrap();
            if std::mem::take(&mut cache.refresh) {
                drop(cache);
                let entries = installed();
                let mut cache = CACHE.lock().unwrap();
                cache.fetched = Some(Instant::now());
                if !entries.is_empty() { cache.entries = Arc::new(entries); }
                drop(cache);
                notify();
            } else if let Some(key) = cache.pending.pop() {
                drop(cache);
                let icon = load_icon(&target(&key.0), key.1);
                let mut cache = CACHE.lock().unwrap();
                if cache.icons.len() >= 384 { cache.icons.clear(); }
                cache.icons.insert(key, icon);
                let done = cache.pending.is_empty();
                drop(cache);
                if done { notify(); }
            } else {
                cache.busy = false;
                break;
            }
        }
        if com.is_ok() { unsafe { CoUninitialize() }; }
    });
}

struct Launcher {
    all: Arc<Vec<Entry>>,
    /// Índices de `all` que batem com a busca.
    shown: Vec<usize>,
    sel: usize,
    top: usize,
    /// Tem texto na busca.
    query: bool,
    icon_px: i32,
    text: String,
}

/// Abre (ou fecha, se já aberto) o lançador, centrado no monitor do cursor.
pub fn toggle() {
    let mut pt = POINT::default();
    let work = unsafe {
        let _ = GetCursorPos(&mut pt);
        let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST), &mut mi);
        mi.rcWork
    };
    // O painel abre sob um "item": aqui, uma faixa a 1/5 da altura, com o painel centrado.
    let y = work.top + (work.bottom - work.top) / 5;
    let item = RECT { left: work.left, top: y, right: work.right, bottom: y };
    preload();
    panel::toggle("launcher", item, || {
        let scale = unsafe { GetDpiForSystem() } as f32 / 96.0;
        let mut l = Launcher {
            all: CACHE.lock().unwrap().entries.clone(),
            shown: Vec::new(),
            sel: 0,
            top: 0,
            query: false,
            icon_px: (24.0 * scale).round() as i32,
            text: String::new(),
        };
        l.filter("");
        Box::new(l)
    });
}

/// Apps da pasta Aplicativos, em ordem alfabética.
pub(crate) fn whatsapp_source() -> Option<String> {
    installed().into_iter().find(|entry| entry.key == "whatsapp" && !entry.id.is_empty())
        .map(|entry| target(&entry.id))
}

fn installed() -> Vec<Entry> {
    let mut out = Vec::new();
    enumerate_apps_folder(&mut out);
    if out.is_empty() {
        let roots = [std::env::var_os("APPDATA"), std::env::var_os("PROGRAMDATA")];
        for root in roots.into_iter().flatten() {
            add_shortcuts(&std::path::Path::new(&root).join("Microsoft/Windows/Start Menu/Programs"), &mut out);
        }
    }
    // Nomes repetidos: fica o que não é gerado.
    let generated = |e: &Entry| e.id.starts_with("Microsoft.AutoGenerated.");
    out.sort_by(|a, b| a.key.cmp(&b.key).then(generated(a).cmp(&generated(b))));
    out.dedup_by(|b, a| a.key == b.key);
    out
}

fn enumerate_apps_folder(out: &mut Vec<Entry>) {
    unsafe {
        let Ok(folder) = SHGetKnownFolderItem::<IShellItem>(&FOLDERID_AppsFolder, KF_FLAG_DEFAULT, None) else {
            return;
        };
        let Ok(items) = folder.BindToHandler::<_, IEnumShellItems>(None, &BHID_EnumItems) else { return };
        let name = |item: &IShellItem, kind| {
            let p = item.GetDisplayName(kind).ok()?;
            let s = p.to_string().ok();
            CoTaskMemFree(Some(p.0 as _));
            s
        };
        loop {
            let mut batch = [None];
            let mut n = 0;
            if items.Next(&mut batch, Some(&mut n)).is_err() || n == 0 {
                break;
            }
            for item in batch.into_iter().take(n as usize).flatten() {
                if let (Some(n), Some(id)) = (name(&item, SIGDN_NORMALDISPLAY), name(&item, SIGDN_PARENTRELATIVEPARSING)) {
                    let key = fold(&n);
                    out.push(Entry { useful: useful(&key, &id), key, name: n, id });
                }
            }
        }
    }
}

fn add_shortcuts(dir: &std::path::Path, out: &mut Vec<Entry>) {
    let Ok(files) = std::fs::read_dir(dir) else { return; };
    for file in files.flatten() {
        let Ok(kind) = file.file_type() else { continue; };
        let path = file.path();
        if kind.is_dir() && file.metadata().is_ok_and(|meta| {
            use std::os::windows::fs::MetadataExt;
            meta.file_attributes() & 0x0400 == 0 // não seguir junções
        }) {
            add_shortcuts(&path, out);
        } else if kind.is_file()
            && path.extension().is_some_and(|ext| ext.eq_ignore_ascii_case("lnk"))
            && let Some(name) = path.file_stem().and_then(|name| name.to_str())
        {
            let key = fold(name);
            let id = path.to_string_lossy().into_owned();
            out.push(Entry { useful: useful(&key, &id), key, name: name.into(), id });
        }
    }
}

fn target(id: &str) -> String {
    if std::path::Path::new(id).is_absolute() { id.to_owned() } else { format!("{APPS_FOLDER}{id}") }
}
/// Pastas do Windows (System32, SysWOW64, Windows) como aparecem nos ids da pasta Aplicativos.
const SYSTEM_DIRS: [&str; 3] = [
    "{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}",
    "{D65231B0-B2F1-4857-A4CE-A8E7C6EA7D27}",
    "{F38BF404-1D43-42F2-9305-67DE0B28FC23}",
];

/// Ferramentas das pastas do Windows que ficam na lista mesmo assim.
const SYSTEM_KEEP: [&str; 2] = [r"\cmd.exe", r"\windowspowershell\v1.0\powershell.exe"];

/// Pedaços de nome (sem acento, minúsculos) de coisas que não são apps do dia a dia.
const NOISE: [&str; 37] = [
    "uninstall", "desinstalar", "documentation", "documentacao", "dokumentation", "docs", "manual",
    "readme", "faq", "release notes", "homepage", "website", "sample", "tools for", "native tools",
    "cross tools", "command prompt", "developer powershell", "install additional tools", "installer",
    "install manager", "(x86)", "(wow)", "pydoc", "idle (", "software development kit", "cert kit",
    "debuggable", "application verifier", "window spy", "ise ", "obter ajuda", "introducao",
    "ferramentas do windows", "legacy", "git cmd", "git gui",
];

/// Ferramentas de administração do Windows que vêm como atalhos gerados (sem caminho).
const ADMIN: [&str; 9] = [
    "agendador de tarefas", "console", "gerenciamento do computador", "monitor de desempenho",
    "monitor de recursos", "visualizador de eventos", "executar", "backup do windows", "acao com um clique",
];

/// Se o app aparece na lista sem busca.
fn useful(key: &str, id: &str) -> bool {
    let lid = id.to_lowercase();
    // Links e documentos (sites, páginas de ajuda, .url).
    if lid.starts_with("http") || [".html", ".htm", ".url", ".chm", ".pdf", ".txt"].iter().any(|e| lid.ends_with(e)) {
        return false;
    }
    // Interpretadores soltos (abrem só um console vazio).
    if [r"\python.exe", r"\node.exe"].iter().any(|e| lid.ends_with(e)) {
        return false;
    }
    if NOISE.iter().any(|n| key.contains(n)) || ADMIN.contains(&key) {
        return false;
    }
    // Utilitários das pastas do Windows (msconfig, regedit, serviços, lupa...).
    if SYSTEM_DIRS.iter().any(|d| id.starts_with(d)) {
        return SYSTEM_KEEP.iter().any(|k| lid.ends_with(k));
    }
    true
}

/// Minúsculas e sem acentos, para "música" achar "Musica".
fn fold(s: &str) -> String {
    s.chars()
        .flat_map(char::to_lowercase)
        .map(|c| match c {
            'á' | 'à' | 'â' | 'ã' | 'ä' => 'a',
            'é' | 'è' | 'ê' | 'ë' => 'e',
            'í' | 'ì' | 'î' | 'ï' => 'i',
            'ó' | 'ò' | 'ô' | 'õ' | 'ö' => 'o',
            'ú' | 'ù' | 'û' | 'ü' => 'u',
            'ç' => 'c',
            c => c,
        })
        .collect()
}

impl Launcher {
    fn filter(&mut self, query: &str) {
        let q = fold(query.trim());
        let words: Vec<&str> = q.split_whitespace().collect();
        let mut hits: Vec<(u8, usize)> = self
            .all
            .iter()
            .enumerate()
            // Sem busca, só os úteis; buscando, todos.
            .filter(|(_, e)| if words.is_empty() { e.useful } else { words.iter().all(|w| e.key.contains(w)) })
            .map(|(i, e)| {
                // Primeiro quem começa com a busca, depois quem tem uma palavra que começa com ela;
                // no mesmo nível, os úteis antes.
                let rank = if e.key.starts_with(&q) {
                    0
                } else if e.key.split_whitespace().any(|w| w.starts_with(&q)) {
                    1
                } else {
                    2
                };
                (rank * 2 + u8::from(!e.useful), i)
            })
            .collect();
        hits.sort();
        self.shown = hits.into_iter().map(|(_, i)| i).collect();
        self.sel = 0;
        self.top = 0;
        self.query = !words.is_empty();
    }

    fn launch(&self, pos: usize) {
        let Some(&i) = self.shown.get(pos) else { return };
        let target = target(&self.all[i].id);
        panel::close();
        unsafe { ShellExecuteW(None, w!("open"), &HSTRING::from(target), None, None, SW_SHOWNORMAL) };
    }

}

impl PanelContent for Launcher {
    fn width(&self) -> f32 {
        720.0
    }
    fn centered(&self) -> bool {
        true
    }
    fn padded(&self) -> bool {
        false
    }
    fn build(&mut self) -> Vec<Widget> {
        let n = self.shown.len();
        let label = match (self.query, n) {
            (_, 0) if CACHE.lock().unwrap().fetched.is_none() => "Carregando aplicativos…".to_string(),
            (_, 0) => "Nenhum aplicativo encontrado".to_string(),
            (false, _) => "Aplicativos".to_string(),
            (true, 1) => "1 resultado".to_string(),
            (true, n) => format!("{n} resultados"),
        };
        let end = (self.top + VISIBLE).min(n);
        let mut cache = CACHE.lock().unwrap();
        let mut pending = Vec::new();
        let items = (self.top..end)
            .map(|pos| {
                let i = self.shown[pos];
                let entry = &self.all[i];
                let key = (entry.id.clone(), self.icon_px);
                let icon = match cache.icons.get(&key) {
                    Some(icon) => icon.clone(),
                    None => { pending.push(key); None }
                };
                (ROW + (pos - self.top) as u32, icon, entry.name.clone())
            })
            .collect();
        pending.reverse();
        cache.pending = pending;
        drop(cache);
        start_worker();
        let scroll = (n > VISIBLE).then(|| (self.top as f32 / n as f32, VISIBLE as f32 / n as f32));
        vec![
            Widget::Search { id: FIELD, placeholder: "Pesquisar aplicativos...".into(), glyph: 0xE721 },
            Widget::Label(label),
            Widget::List { items, rows: VISIBLE, selected: (n > 0).then(|| self.sel - self.top), scroll },
            Widget::Footer {
                left: Some((0xE71D, "Aplicativos".into())),
                hints: vec![("Abrir".into(), vec!["Enter".into()]), ("Fechar".into(), vec!["Esc".into()])],
            },
        ]
    }
    fn notify(&mut self, msg: u32, _: usize) -> bool {
        if msg != WM_LOADED { return false; }
        let entries = CACHE.lock().unwrap().entries.clone();
        if !Arc::ptr_eq(&entries, &self.all) {
            self.all = entries;
            self.filter(&self.text.clone());
        }
        true
    }
    fn event(&mut self, ev: Event) -> bool {
        match ev {
            Event::Text(FIELD, t) => {
                self.text = t.to_owned();
                self.filter(t);
                true
            }
            Event::Submit(FIELD, _) => {
                self.launch(self.sel);
                false
            }
            Event::Click(id) if id >= ROW => {
                self.launch(self.top + (id - ROW) as usize);
                false
            }
            Event::Key(k) if !self.shown.is_empty() => {
                let last = self.shown.len() - 1;
                self.sel = if k == VK_UP.0 {
                    self.sel.saturating_sub(1)
                } else if k == VK_DOWN.0 {
                    (self.sel + 1).min(last)
                } else {
                    self.sel
                };
                if self.sel < self.top {
                    self.top = self.sel;
                } else if self.sel >= self.top + VISIBLE {
                    self.top = self.sel + 1 - VISIBLE;
                }
                true
            }
            _ => false,
        }
    }
}
