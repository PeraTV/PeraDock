# PeraDock

Esta atualização melhora a leitura de ícones de executáveis e atalhos do Windows, inclusive atalhos de jogos da Steam. O PeraDock preserva a transparência dos ícones antigos e recorta margens que podem deixar alguns desenhos pequenos ou emoldurados.

Compatível com Windows x64. Extraia o ZIP, feche a versão anterior e abra PeraDock.exe.

- Para mudar a posição, use **Configurações → Dock** ou **Dock 2**. Também é possível segurar o botão do meio sobre a dock, arrastar o cursor e soltar perto de uma das quatro bordas.
- Arraste um ícone com o botão esquerdo para reordenar os atalhos. O ícone acompanha o cursor e os vizinhos deslizam para abrir espaço. A Dock 1 permite reorganizar os apps fixados e arrastar um app aberto para a área de fixados.
- Para mostrar nomes ao passar o mouse, ative **Mostrar nome dos aplicativos** separadamente em **Dock** e **Dock 2**. As duas opções vêm desligadas. A Dock 2 mostra os nomes em um cartão arredondado.
- Em **Configurações → Geral**, escolha **Preto** ou **Branco** em **Tema das configurações**.
- Para checar outra versão, use **Configurações → Geral → Verificar atualizações**.

O PeraDock é um projeto independente e o executável não tem assinatura digital. O Windows pode exibir um aviso do SmartScreen ao abrir. O alerta por si só não indica que o arquivo é malicioso. Baixe pelo repositório oficial do projeto.

O código-fonte está na pasta Codigo-fonte. Para compilar, execute Compilar-PeraDock.ps1 no PowerShell com Rust e Cargo instalados. A licença MIT está em Codigo-fonte/LICENSE.